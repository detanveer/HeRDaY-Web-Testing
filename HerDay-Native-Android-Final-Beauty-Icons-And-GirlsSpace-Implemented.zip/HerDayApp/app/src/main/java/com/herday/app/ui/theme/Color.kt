package com.herday.app.ui.theme

import androidx.compose.ui.graphics.Color

// #01 approved Home master background.
val HomeBackground = Color(0xFFFCE8EF)

// #05 approved Hero mask base color (peak alpha 188/255 applied separately in HeroMask.kt).
val HeroMaskBase = Color(0xFFFCE8EF)

// #05 / #06 approved Hero text color: "Deep Rose Plum", shared by greeting/name/subtitle.
val HeroTextColor = Color(0xFF6F3F55)
