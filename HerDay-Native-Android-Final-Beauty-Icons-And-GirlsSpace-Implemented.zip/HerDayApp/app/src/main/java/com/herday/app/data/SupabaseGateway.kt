package com.herday.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Live Supabase gateway. Contains only the client-safe publishable key; RLS/RPCs remain authoritative. */
class SupabaseGateway(context: Context) {
    companion object {
        const val URL = "https://mxokajwumvkdtdnjqkhw.supabase.co"
        const val PUBLISHABLE_KEY = "sb_publishable_EcHg4SrOtEP5EgVOCG9ylQ_WLkQjcyC"
        const val PROFILE_BUCKET = "profile-photos"
        const val BEAUTY_BUCKET = "beauty-profile-photos"
    }

    private val preferences = context.getSharedPreferences("herday_session", Context.MODE_PRIVATE)
    var session: Session? = restoreSession(); private set

    private fun restoreSession(): Session? {
        val user = preferences.getString("uid", null) ?: return null
        return Session(user, preferences.getString("email", "") ?: "", preferences.getString("access", "") ?: "", preferences.getString("refresh", "") ?: "")
            .takeIf { it.accessToken.isNotBlank() }
    }

    private fun persist(value: Session?) {
        session = value
        preferences.edit().clear().apply {
            value?.let { putString("uid", it.userId); putString("email", it.email); putString("access", it.accessToken); putString("refresh", it.refreshToken) }
        }.apply()
    }

    suspend fun signUp(first: String, last: String, email: String, cell: String?, password: String): Session = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password).put("data", JSONObject().put("first_name", first).put("last_name", last).put("cell_number", cell ?: JSONObject.NULL))
        parseAuth(request("/auth/v1/signup", "POST", body, authenticated = false), email).also(::persist)
    }

    suspend fun signIn(email: String, password: String): Session = withContext(Dispatchers.IO) {
        parseAuth(request("/auth/v1/token?grant_type=password", "POST", JSONObject().put("email", email).put("password", password), authenticated = false), email).also(::persist)
    }

    suspend fun refreshSession(): Session? = withContext(Dispatchers.IO) {
        val current = session ?: return@withContext null
        runCatching {
            parseAuth(request("/auth/v1/token?grant_type=refresh_token", "POST", JSONObject().put("refresh_token", current.refreshToken), authenticated = false), current.email)
        }.getOrNull()?.also(::persist)
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        runCatching { request("/auth/v1/logout", "POST", JSONObject()) }
        persist(null)
    }

    suspend fun accountProfile(): AccountProfile = withContext(Dispatchers.IO) {
        val s = requireSession()
        val array = JSONArray(request("/rest/v1/profiles?id=eq.${s.userId}&select=id,first_name,last_name,cell_number,avatar_path,role,is_blocked", "GET"))
        if (array.length() == 0) throw SupabaseException(null, "Account profile is unavailable.", 404)
        val row = array.getJSONObject(0)
        AccountProfile(s.userId, row.optString("first_name"), row.optString("last_name"), s.email, row.nullableString("cell_number"), row.nullableString("avatar_path"), row.optString("role", "user"), row.optBoolean("is_blocked"))
    }

    suspend fun ownerBeautyProfile(): BeautyProfile? = withContext(Dispatchers.IO) {
        val uid = requireSession().userId
        val rows = JSONArray(request("/rest/v1/beauty_profiles?owner_id=eq.$uid&select=*&limit=1", "GET"))
        if (rows.length() == 0) null else rows.getJSONObject(0).toBeautyProfile()
    }

    suspend fun approvedProviders(category: String?, area: String?): List<BeautyProfile> = withContext(Dispatchers.IO) {
        val query = buildString {
            append("/rest/v1/beauty_profiles?verification_status=eq.approved&verified=eq.true&is_public=eq.true&select=*")
            if (!category.isNullOrBlank()) append("&categories=cs.").append(Uri.encode("{\"$category\"}"))
            if (!area.isNullOrBlank()) append("&service_areas=cs.").append(Uri.encode("{\"$area\"}"))
        }
        JSONArray(request(query, "GET")).toObjects().map { it.toBeautyProfile() }
    }

    suspend fun pendingProfiles(): List<BeautyProfile> = withContext(Dispatchers.IO) {
        JSONArray(request("/rest/v1/beauty_profiles?verification_status=eq.pending&select=*&order=verification_submitted_at.asc", "GET")).toObjects().map { it.toBeautyProfile() }
    }

    suspend fun searchPakistanLocations(query: String): List<String> = withContext(Dispatchers.IO) {
        if (query.trim().length < 2) return@withContext emptyList()
        val url = java.net.URL("https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&countrycodes=pk&limit=6&q=${Uri.encode(query.trim())}")
        val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 15_000; readTimeout = 15_000; setRequestProperty("User-Agent", "HerDay-Android/1.0") }
        if (connection.responseCode !in 200..299) return@withContext emptyList()
        JSONArray(connection.inputStream.bufferedReader().use { it.readText() }).toObjects().mapNotNull { row ->
            val address = row.optJSONObject("address") ?: JSONObject()
            row.optString("name").trim().takeIf(String::isNotBlank)
                ?: listOf("suburb", "neighbourhood", "city_district", "city", "town", "village")
                    .firstNotNullOfOrNull { key -> address.optString(key).trim().takeIf(String::isNotBlank) }
        }.distinct().take(6)
    }

    suspend fun reversePakistanLocation(latitude: Double, longitude: Double): String = withContext(Dispatchers.IO) {
        val url = java.net.URL(
            "https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1" +
                "&lat=$latitude&lon=$longitude"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "HerDay-Android/1.0")
        }
        if (connection.responseCode !in 200..299) {
            throw SupabaseException(null, "Current area could not be resolved. Please retry or choose a location.", connection.responseCode)
        }
        val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        val address = root.optJSONObject("address") ?: JSONObject()
        val countryCode = address.optString("country_code")
        if (countryCode.isNotBlank() && countryCode.lowercase() != "pk") {
            throw IllegalStateException("Near Me is currently available for locations in Pakistan.")
        }
        listOf("suburb", "neighbourhood", "quarter", "city_district", "city", "town", "village")
            .firstNotNullOfOrNull { key -> address.optString(key).trim().takeIf(String::isNotBlank) }
            ?: root.optString("name").trim().takeIf(String::isNotBlank)
            ?: throw IllegalStateException("Current area could not be identified. Please choose a location.")
    }

    suspend fun createBeautyProfile(draft: BeautyDraft): BeautyProfile = withContext(Dispatchers.IO) {
        val body = draft.toJson().put("owner_id", requireSession().userId)
        val response = request("/rest/v1/beauty_profiles", "POST", body, preferRepresentation = true)
        JSONArray(response).getJSONObject(0).toBeautyProfile()
    }

    suspend fun updateBeautyProfile(id: String, draft: BeautyDraft) = rpc("update_own_beauty_profile", draft.toRpcJson(id))
    suspend fun submitVerification(id: String) = rpc("submit_beauty_profile_verification", JSONObject().put("target_profile_id", id))
    suspend fun approve(id: String, checks: List<Boolean>) = rpc("approve_beauty_profile", JSONObject().put("target_profile_id", id).put("whatsapp_number_matches", checks[0]).put("professional_name_matches", checks[1]).put("services_match", checks[2]).put("service_areas_match", checks[3]))
    suspend fun requestCorrection(id: String, reason: String, note: String?) = rpc("request_beauty_profile_correction", JSONObject().put("target_profile_id", id).put("selected_reason", reason).put("selected_note", note ?: JSONObject.NULL))

    private suspend fun rpc(name: String, body: JSONObject) = withContext(Dispatchers.IO) { request("/rest/v1/rpc/$name", "POST", body) }

    suspend fun uploadBeautyPhoto(bytes: ByteArray, extension: String, mime: String): String = withContext(Dispatchers.IO) {
        require(bytes.size <= 5 * 1024 * 1024) { "Photo must be 5 MB or smaller." }
        require(mime in setOf("image/jpeg", "image/png", "image/webp")) { "Use JPEG, PNG or WebP." }
        val path = "${requireSession().userId}/profile-${System.currentTimeMillis()}.$extension"
        requestBytes("/storage/v1/object/$BEAUTY_BUCKET/$path", "POST", bytes, mime)
        path
    }

    suspend fun signedBeautyPhotoUrl(path: String): String = withContext(Dispatchers.IO) {
        val json = JSONObject(request("/storage/v1/object/sign/$BEAUTY_BUCKET/$path", "POST", JSONObject().put("expiresIn", 3600)))
        val signed = json.optString("signedURL", json.optString("signedUrl"))
        if (signed.startsWith("http")) signed else "$URL/storage/v1$signed"
    }

    private fun requireSession() = session ?: throw SupabaseException(null, "Please log in again.", 401)

    private fun parseAuth(json: String, fallbackEmail: String): Session {
        val root = JSONObject(json)
        val user = root.optJSONObject("user") ?: throw SupabaseException(null, "Check your email to confirm your account, then log in.", 202)
        val access = root.optString("access_token")
        if (access.isBlank()) throw SupabaseException(null, "Check your email to confirm your account, then log in.", 202)
        return Session(user.getString("id"), user.optString("email", fallbackEmail), access, root.optString("refresh_token"))
    }

    private fun request(path: String, method: String, body: JSONObject? = null, authenticated: Boolean = true, preferRepresentation: Boolean = false): String {
        val connection = (java.net.URL(URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 20_000; readTimeout = 25_000
            setRequestProperty("apikey", PUBLISHABLE_KEY)
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            if (authenticated) setRequestProperty("Authorization", "Bearer ${requireSession().accessToken}")
            if (preferRepresentation) setRequestProperty("Prefer", "return=representation")
            if (body != null) { doOutput = true; outputStream.use { it.write(body.toString().toByteArray()) } }
        }
        return connection.readResult()
    }

    private fun requestBytes(path: String, method: String, bytes: ByteArray, mime: String): String {
        val connection = (java.net.URL(URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 20_000; readTimeout = 30_000; doOutput = true
            setRequestProperty("apikey", PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer ${requireSession().accessToken}")
            setRequestProperty("Content-Type", mime); setRequestProperty("x-upsert", "false")
            outputStream.use { it.write(bytes) }
        }
        return connection.readResult()
    }

    private fun HttpURLConnection.readResult(): String {
        val ok = responseCode in 200..299
        val text = (if (ok) inputStream else errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (!ok) {
            val error = runCatching { JSONObject(text) }.getOrNull()
            throw SupabaseException(error?.optString("code")?.takeIf(String::isNotBlank), error?.optString("message")?.takeIf(String::isNotBlank) ?: "Supabase request failed.", responseCode)
        }
        return text.ifBlank { "{}" }
    }
}

private fun JSONObject.nullableString(key: String) = if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
private fun JSONArray.toObjects() = (0 until length()).map { getJSONObject(it) }
private fun JSONArray.toStrings() = (0 until length()).map { getString(it) }
private fun JSONObject.stringList(key: String) = optJSONArray(key)?.toStrings().orEmpty()
private fun JSONObject.toBeautyProfile() = BeautyProfile(
    getString("id"), getString("owner_id"), optString("professional_name"), optString("about"), nullableString("professional_photo_path"),
    optString("whatsapp_number"), stringList("categories"), stringList("services"), stringList("service_areas"), optString("verification_status", "draft"),
    optBoolean("verified"), optBoolean("is_public"), nullableString("correction_reason"), nullableString("correction_note")
)
private fun List<String>.jsonArray() = JSONArray().also { array -> forEach(array::put) }
private fun BeautyDraft.toJson() = JSONObject().put("professional_name", professionalName.trim()).put("about", about.trim()).put("professional_photo_path", professionalPhotoPath ?: JSONObject.NULL).put("whatsapp_number", whatsappNumber.trim()).put("categories", categories.jsonArray()).put("services", services.jsonArray()).put("service_areas", serviceAreas.jsonArray())
private fun BeautyDraft.toRpcJson(id: String) = JSONObject().put("target_profile_id", id).put("new_professional_name", professionalName.trim()).put("new_about", about.trim()).put("new_professional_photo_path", professionalPhotoPath ?: JSONObject.NULL).put("new_whatsapp_number", whatsappNumber.trim()).put("new_categories", categories.jsonArray()).put("new_services", services.jsonArray()).put("new_service_areas", serviceAreas.jsonArray())
