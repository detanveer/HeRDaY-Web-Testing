package com.herday.app.ui

import android.content.Intent
import android.Manifest
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.herday.app.*
import com.herday.app.R
import com.herday.app.data.*
import com.herday.app.ui.hero.HomeScreen
import com.herday.app.ui.hero.BottomNavigation
import com.herday.app.ui.navigation.FeaturePlaceholderScreen
import com.herday.app.ui.navigation.FeatureSection
import com.herday.app.location.NearMeLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

private val Plum = Color(0xFF5F123D)
private val Pink = Color(0xFFE92878)
private val Pale = Color(0xFFFFF3F7)
private val Muted = Color(0xFF745B6B)
private val Serif = FontFamily(Font(R.font.dm_serif_display_regular))
private val Poppins = FontFamily(Font(R.font.poppins_regular))
private val Line = Color(0xFFEFDDE5)
private val CardSurface = Color(0xFFFFFDFD)
private val Green = Color(0xFF08AA67)
private val LocalController = staticCompositionLocalOf<AppController> { error("AppController unavailable") }

@Composable
fun HerDayNativeApp(controller: AppController = viewModel()) {
    val error = controller.error
    CompositionLocalProvider(LocalController provides controller) { Box(Modifier.fillMaxSize().background(Pale)) {
        when (controller.route) {
            AppRoute.Login -> LoginScreen(controller)
            AppRoute.SignUp -> SignUpScreen(controller)
            AppRoute.Home -> HomeScreen(controller::openHomeFeature)
            AppRoute.Placeholder -> controller.placeholder?.let { FeaturePlaceholderScreen(it) { controller.go(AppRoute.Home) } }
            AppRoute.BeautyMain -> BeautyMainScreen(controller)
            AppRoute.BeautyCategories -> AllBeautyCategoriesScreen(controller)
            AppRoute.BeautyEditor -> BeautyEditorScreen(controller)
            AppRoute.VerifyInfo -> VerifyInfoScreen(controller)
            AppRoute.Pending -> PendingScreen(controller)
            AppRoute.MyBeauty -> MyBeautyScreen(controller)
            AppRoute.PublicBeauty -> PublicBeautyScreen(controller)
            AppRoute.Profile -> ProfileScreen(controller)
            AppRoute.Admin -> AdminScreen(controller)
            AppRoute.AdminPending -> AdminPendingScreen(controller)
            AppRoute.AdminReview -> AdminReviewScreen(controller)
        }
        if (controller.busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .12f)), Alignment.Center) { CircularProgressIndicator(color = Pink) }
        if (error != null) AlertDialog(onDismissRequest = controller::clearError, confirmButton = { TextButton(onClick = controller::clearError) { Text("OK") } }, title = { Text("HerDay") }, text = { Text(error) })
    } }
}

@Composable private fun LoginScreen(c: AppController) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    AuthShell("Welcome back", "Log in to continue to HerDay.") {
        LabeledField("Email", email, { email = it }, "Enter your email")
        LabeledField("Password", password, { password = it }, "Enter your password", true)
        PrimaryButton("Log In", enabled = email.isNotBlank() && password.isNotBlank()) { c.login(email, password) }
        TextButton(onClick = { c.go(AppRoute.SignUp) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Don't have an account? Sign Up", color = Pink) }
    }
}

@Composable private fun SignUpScreen(c: AppController) {
    var first by remember { mutableStateOf("") }; var last by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var cell by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }
    AuthShell("Create your account", "Join HerDay and make it yours.") {
        LabeledField("First Name", first, { first = it }, "Enter first name")
        LabeledField("Last Name", last, { last = it }, "Enter last name")
        LabeledField("Email", email, { email = it }, "Enter your email")
        LabeledField("Cell Number (Optional)", cell, { cell = it }, "Enter cell number")
        LabeledField("Password", password, { password = it }, "Minimum 8 characters", true)
        LabeledField("Confirm Password", confirm, { confirm = it }, "Confirm your password", true)
        Spacer(Modifier.height(8.dp))
        PrimaryButton("Create Account", enabled = first.isNotBlank() && last.isNotBlank() && email.isNotBlank() && password.length >= 8 && password == confirm) { c.signUp(first, last, email, cell.ifBlank { null }, password) }
        Text("By creating an account, you agree to HerDay's Terms & Privacy Policy.", color = Muted, fontFamily = Poppins, fontSize = 12.sp, textAlign = TextAlign.Center)
        TextButton(onClick = { c.go(AppRoute.Login) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Already have an account? Log In", color = Pink) }
    }
}

@Composable private fun AuthShell(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("HerDay♡", color = Pink, fontFamily = Serif, fontSize = 42.sp)
        Spacer(Modifier.height(22.dp)); Text(title, color = Plum, fontFamily = Serif, fontSize = 38.sp, textAlign = TextAlign.Center)
        Text(subtitle, color = Muted, fontFamily = Poppins, fontSize = 16.sp); Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }
    }
}

@Composable private fun LabeledField(label: String, value: String, onValue: (String) -> Unit, hint: String, password: Boolean = false, singleLine: Boolean = true) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Plum, fontFamily = Poppins, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), placeholder = { Text(hint) }, singleLine = singleLine, visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, shape = RoundedCornerShape(14.dp))
    }
}

@Composable private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) { Button(onClick, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(Pink)) { Text(text, fontFamily = Poppins, fontWeight = FontWeight.Bold) } }

@Composable private fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalController.current
    if (onBack != null) BackHandler(onBack = onBack)
    BoxWithConstraints(Modifier.fillMaxSize().background(Pale).windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))) {
        val scale = (maxWidth * .92f).value / 882f
        val navHeight = 144.dp * scale
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Text("‹", color = Pink, fontSize = 36.sp) }
                Spacer(Modifier.weight(1f))
                Image(painterResource(R.drawable.logo_herday), "HerDay", Modifier.width(112.dp).height(42.dp), contentScale = ContentScale.Fit)
            }
            Text(title, color = Plum, fontFamily = Serif, fontSize = 36.sp)
            content(); Spacer(Modifier.height(navHeight + 42.dp))
        }
        BottomNavigation(
            scale,
            Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Bottom)).padding(bottom = 8.dp),
            activeIndex = when (c.route) { AppRoute.Profile, AppRoute.Admin, AppRoute.AdminPending, AppRoute.AdminReview -> 4; AppRoute.Placeholder -> when (c.placeholder) { FeatureSection.Explore -> 1; FeatureSection.BuySell -> 2; FeatureSection.Shop -> 3; else -> 0 }; else -> 0 },
            onSelected = { index ->
                when (index) {
                    0 -> c.go(AppRoute.Home)
                    1 -> c.openHomeFeature(FeatureSection.Explore)
                    2 -> c.openHomeFeature(FeatureSection.BuySell)
                    3 -> c.openHomeFeature(FeatureSection.Shop)
                    4 -> c.go(AppRoute.Profile)
                }
            }
        )
    }
}

@Composable private fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Card(modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(CardSurface), border = BorderStroke(1.dp, Line), elevation = CardDefaults.cardElevation(3.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }
@Composable private fun H2(text: String) = Text(text, color = Color(0xFF1C1028), fontFamily = Serif, fontSize = 25.sp, lineHeight = 29.sp)
@Composable private fun Body(text: String) = Text(text, color = Muted, fontFamily = Poppins, fontSize = 14.sp, lineHeight = 21.sp)

@Composable private fun RoundBeautyIcon(symbol: String, size: Int = 52) = Box(Modifier.size(size.dp).background(Color(0xFFFDEAF2), CircleShape), Alignment.Center) { Text(symbol, color = Pink, fontSize = (size * .45f).sp) }

@Composable private fun BeautyCategoryIcon(category: String, size: Int = 48) = Box(
    Modifier.size(size.dp).background(Color(0xFFFDEAF2), CircleShape),
    Alignment.Center
) {
    Image(
        painter = painterResource(beautyCategoryDrawable(category)),
        contentDescription = category,
        contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize()
    )
}

@Composable private fun StatusPill(text: String) = Surface(color = Color(0xFFFFF2DC), shape = RoundedCornerShape(99.dp)) { Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF9D6B1F), fontFamily = Poppins, fontSize = 11.sp) }

@Composable private fun BeautyMainScreen(c: AppController) {
    var category by remember { mutableStateOf<String?>(null) }; var area by remember { mutableStateOf("") }; var manualMode by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val acquireLocation = remember(context, category) {{
        NearMeLocation.acquire(context, { location -> c.useNearMe(location.latitude, location.longitude, category) }, c::showMessage)
    }}
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) acquireLocation() else c.showMessage("Location permission was denied. You can retry Near Me or choose a location.")
    }
    Page("Beauty Services", { c.go(AppRoute.Home) }) {
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) { Image(painterResource(R.drawable.ic_beauty_services), null, Modifier.size(54.dp)); Column { H2("Find beauty services near you"); Body("Choose how you want to search") } }
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(15.dp)).padding(3.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(onClick = { manualMode = false; if (NearMeLocation.hasPermission(context)) acquireLocation() else permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Line), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (!manualMode) Color(0xFFFFF0F6) else Color.White)) { Text("⌖  Near Me", color = Pink, fontFamily = Poppins) }
                OutlinedButton(onClick = { manualMode = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Line), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (manualMode) Color(0xFFFFF0F6) else Color.White)) { Text("Choose Location", color = Plum, fontFamily = Poppins) }
            }
            c.selectedBeautyArea?.let { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { RoundBeautyIcon("⌖", 44); Column { Text("Current search area", color = Muted, fontSize = 12.sp); Text(it, color = Plum, fontFamily = Serif, fontSize = 20.sp) } } }
            if (manualMode) {
                LabeledField("Choose Location", area, { area = it; c.searchLocations(it) }, "Search an area or address in Pakistan")
                c.locationSuggestions.forEach { suggestion -> Text("⌖  $suggestion", color = Plum, fontFamily = Poppins, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(11.dp)).clickable { area = suggestion; c.selectBeautyArea(suggestion, category) }.padding(11.dp)) }
            }
            PrimaryButton("Find Providers") { val chosen = area.ifBlank { c.selectedBeautyArea.orEmpty() }; if (chosen.isBlank()) c.showMessage("Use Near Me or choose a location first.") else c.selectBeautyArea(chosen, category) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            H2("Explore Beauty")
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { c.go(AppRoute.BeautyCategories) }) { Text("View All  ›", color = Pink, fontFamily = Poppins) }
        }
        quickBeautyCategories.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { item -> Card(Modifier.weight(1f).clickable { category = if (category == item) null else item; c.loadProviders(category, c.selectedBeautyArea ?: area.ifBlank { null }) }, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(if (category == item) Color(0xFFFFE6F0) else Color.White), border = BorderStroke(1.dp, Line)) { Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) { BeautyCategoryIcon(item, 48); Text(item, color = Plum, fontFamily = Poppins, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2) } } } } }
        when (val state = c.beautyState) {
            OwnerBeautyState.Loading -> CircularProgressIndicator(color = Pink)
            OwnerBeautyState.NoProfile -> SectionCard { H2("Do you offer beauty services?"); Body("Create your professional Beauty Profile on HerDay."); PrimaryButton("Create Beauty Profile") { c.enterCreateOrExisting() } }
            is OwnerBeautyState.Draft -> StateEntry("Continue Beauty Profile", "Finish your existing draft.") { c.enterCreateOrExisting() }
            is OwnerBeautyState.NeedsCorrection -> StateEntry("Beauty Profile Needs Correction", state.profile.correctionReason ?: "Update your existing profile and resubmit.") { c.enterCreateOrExisting() }
            is OwnerBeautyState.Pending -> StateEntry(state.profile.professionalName, "Pending Review") { c.go(AppRoute.Pending) }
            is OwnerBeautyState.Approved -> StateEntry(state.profile.professionalName, "Verified ✓") { c.go(AppRoute.MyBeauty) }
            is OwnerBeautyState.UnknownExisting -> StateEntry(state.profile.professionalName, "Profile status unavailable — creation is safely blocked.") { }
            is OwnerBeautyState.Error -> SectionCard { Body(state.message); OutlinedButton({ c.enterBeauty() }, Modifier.fillMaxWidth()) { Text("Retry") } }
        }
        H2("Approved Providers")
        if (c.providers.isEmpty()) SectionCard { Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { RoundBeautyIcon("⌖"); H2("No matching professionals yet"); Body("No live approved Beauty professional serves this selection yet.") } }
        c.providers.forEach { provider -> SectionCard(Modifier.clickable { c.openProvider(provider) }) { Row(horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.Top) { Box(Modifier.size(76.dp).background(Color(0xFFFDEAF2), CircleShape), Alignment.Center) { Text("♙", color = Pink, fontSize = 36.sp) }; Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { H2(provider.professionalName); if (provider.verified) Text("  ✓", color = Pink, fontWeight = FontWeight.Bold) }; Body(provider.categories.joinToString(" · ")); Body(provider.services.take(3).joinToString(" · ")); Body("⌖ Serves ${provider.serviceAreas.joinToString(", ")}"); OutlinedButton({ c.openProvider(provider) }, Modifier.align(Alignment.End), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Color(0xFFE8B9CC))) { Text("View Profile ›", color = Pink) } } } } }
        TextButton(onClick = { c.go(AppRoute.Profile) }, modifier = Modifier.fillMaxWidth()) { Text("Account & Profile", color = Pink) }
    }
}

@Composable private fun AllBeautyCategoriesScreen(c: AppController) {
    Page("All Beauty Categories", { c.go(AppRoute.BeautyMain) }) {
        Body("What are you looking for?")
        allBeautyCategories.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { item ->
                    Card(
                        Modifier.weight(1f).heightIn(min = 96.dp).clickable {
                            c.loadProviders(item, c.selectedBeautyArea)
                            c.go(AppRoute.BeautyMain)
                        },
                        RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(Color.White),
                        border = BorderStroke(1.dp, Line)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            BeautyCategoryIcon(item, 58)
                            Text(item, color = Plum, fontFamily = Poppins, fontSize = 14.sp, lineHeight = 19.sp, modifier = Modifier.weight(1f), maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StateEntry(title: String, subtitle: String, onClick: () -> Unit) = SectionCard(Modifier.clickable(onClick = onClick)) { Row(horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) { RoundBeautyIcon(if (subtitle.contains("Pending", true)) "◷" else "♧", 58); Column(Modifier.weight(1f)) { H2(title); Body(subtitle); Text("Open ›", color = Pink, fontFamily = Poppins, fontWeight = FontWeight.SemiBold) } } }

private fun stateProfile(state: OwnerBeautyState): BeautyProfile? = when (state) { is OwnerBeautyState.Draft -> state.profile; is OwnerBeautyState.NeedsCorrection -> state.profile; is OwnerBeautyState.Pending -> state.profile; is OwnerBeautyState.Approved -> state.profile; is OwnerBeautyState.UnknownExisting -> state.profile; else -> null }

@Composable private fun BeautyEditorScreen(c: AppController) {
    val existing = stateProfile(c.beautyState)
    var name by remember(existing?.id) { mutableStateOf(existing?.professionalName.orEmpty()) }; var about by remember(existing?.id) { mutableStateOf(existing?.about.orEmpty()) }; var whatsapp by remember(existing?.id) { mutableStateOf(existing?.whatsappNumber.orEmpty()) }; var services by remember(existing?.id) { mutableStateOf(existing?.services?.joinToString("\n").orEmpty()) }; var areas by remember(existing?.id) { mutableStateOf(existing?.serviceAreas?.joinToString("\n").orEmpty()) }; var categories by remember(existing?.id) { mutableStateOf(existing?.categories.orEmpty().toSet()) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(c::uploadBeautyPhoto) }
    Page(if (existing == null) "Create Beauty Profile" else "Edit Beauty Profile", { c.go(AppRoute.BeautyMain) }) {
        if (c.beautyState is OwnerBeautyState.NeedsCorrection) SectionCard { H2("Needs Correction"); Body(existing?.correctionReason.orEmpty()); existing?.correctionNote?.let { Body(it) } }
        SectionCard {
            H2("Professional Profile")
            Body(if (c.uploadedBeautyPhotoPath != null || existing?.professionalPhotoPath != null) "Professional photo selected securely." else "Add a professional photo (JPEG, PNG or WebP; maximum 5 MB).")
            OutlinedButton({ photoPicker.launch("image/*") }, Modifier.fillMaxWidth()) { Text("Choose Professional Photo", color = Pink) }
            LabeledField("Professional / Parlor Name", name, { name = it }, "Enter professional name")
            LabeledField("About", about, { about = it }, "Tell customers about your services", singleLine = false)
            LabeledField("WhatsApp Number", whatsapp, { whatsapp = it }, "03XX XXXXXXX")
        }
        H2("Beauty Categories")
        allBeautyCategories.forEach { item -> Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(item in categories, { categories = if (it) categories + item else categories - item }); Text(item, color = Plum, fontFamily = Poppins) } }
        SectionCard { LabeledField("Services", services, { services = it }, "One service per line", singleLine = false); LabeledField("Service Areas", areas, { areas = it }, "One area per line", singleLine = false) }
        val draft = BeautyDraft(name, about, c.uploadedBeautyPhotoPath ?: existing?.professionalPhotoPath, whatsapp, categories.toList(), services.lines().map(String::trim).filter(String::isNotBlank), areas.lines().map(String::trim).filter(String::isNotBlank))
        val valid = name.isNotBlank() && whatsapp.isNotBlank() && categories.isNotEmpty() && draft.services.isNotEmpty() && draft.serviceAreas.isNotEmpty()
        PrimaryButton(if (existing == null) "Save & Continue" else "Save Existing Profile", valid) { c.saveBeauty(draft) }
    }
}

@Composable private fun VerifyInfoScreen(c: AppController) {
    val context = LocalContext.current
    var whatsAppOpened by remember { mutableStateOf(false) }
    Page("Verify Your Beauty Profile", { c.go(AppRoute.BeautyEditor) }) {
        SectionCard { Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) { RoundBeautyIcon("♪✓", 82); Column(Modifier.weight(1f)) { H2("Voice Verification"); Body("Send us a short voice note from the WhatsApp number entered in your Beauty Profile."); StatusPill("♪  WhatsApp voice note") } } }
        SectionCard { H2("What to mention"); Body("Please include only these three details:"); listOf("Your Beauty Profile / Professional Name", "The beauty services you provide", "The areas where you provide your services").forEachIndexed { i, text -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) { RoundBeautyIcon("${i + 1}", 38); Text(text, color = Plum, fontFamily = Poppins, fontSize = 13.sp, modifier = Modifier.weight(1f)) } } }
        SectionCard { Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) { RoundBeautyIcon("✓", 44); Column { Text("No video, CNIC or documents required.", color = Plum, fontFamily = Poppins, fontWeight = FontWeight.SemiBold); Body("Your voice note is only used to confirm the details submitted in your Beauty Profile.") } } }
        PrimaryButton("Send Verification Voice Note") { whatsAppOpened = true; openUrl(context, "https://wa.me/923332636786") }
        Body("WhatsApp will open so you can record and send the voice note yourself. The composer is empty.")
        OutlinedButton({ c.submitVoiceConfirmation() }, Modifier.fillMaxWidth().heightIn(min = 50.dp), enabled = whatsAppOpened, shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, Color(0xFFE8B9CC))) { Text("I've Sent My Voice Note", color = Pink, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable private fun PendingScreen(c: AppController) {
    Page("Verification Submitted", { c.go(AppRoute.BeautyMain) }) {
        SectionCard { Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) { RoundBeautyIcon("♪✓", 78); Column(Modifier.weight(1f)) { H2("Verification Submitted"); StatusPill("◷  Pending Review"); Body("HerDay will review the details provided for your Beauty Profile.") } } }
        SectionCard { H2("What happens next?"); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { listOf("▤" to "Details\nSubmitted", "✓" to "HerDay\nReview", "♙" to "Profile\nApproved").forEach { (icon, text) -> Column(horizontalAlignment = Alignment.CenterHorizontally) { RoundBeautyIcon(icon, 46); Text(text, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 15.sp) } } }; Body("Your Beauty Profile remains pending while HerDay reviews the submitted details. After approval, it can go live with HerDay verification status.") }
        SectionCard { Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) { RoundBeautyIcon("♙", 46); Column(Modifier.weight(1f)) { H2("Beauty Profile"); StatusPill("◷ Awaiting Verification Approval"); Body("Your Beauty Profile will not appear in public provider searches until verification is approved.") } } }
        SectionCard { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { RoundBeautyIcon("ⓘ", 42); Column(Modifier.weight(1f)) { Text("No action is needed while your verification is under review.", color = Plum, fontWeight = FontWeight.SemiBold); Body("You do not need to send anything else unless HerDay requests a correction.") } } }
        PrimaryButton("Back to Beauty Services") { c.go(AppRoute.BeautyMain) }
        Body("Need help? Contact HerDay support.")
    }
}

@Composable private fun MyBeautyScreen(c: AppController) {
    val p = stateProfile(c.beautyState)
    Page("My Beauty Profile", { c.go(AppRoute.BeautyMain) }) { if (p == null) Body("Profile unavailable.") else { SectionCard { H2(p.professionalName); Text("Verified ✓", color = Pink); Body(p.about); Body(p.categories.joinToString(" • ")) }; PrimaryButton("View Public Profile") { c.openProvider(p) } } }
}

@Composable private fun PublicBeautyScreen(c: AppController) {
    val p = c.selectedProvider
    val context = LocalContext.current
    Page(p?.professionalName ?: "Beauty Profile", { c.go(AppRoute.BeautyMain) }) {
        if (p == null) Body("Profile unavailable.") else {
            SectionCard { PrivateBeautyPhoto(c, p.professionalPhotoPath); H2(p.professionalName); if (p.verified) Text("Verified ✓", color = Pink); Body(p.about) }
            SectionCard { H2("Beauty Categories"); Body(p.categories.joinToString(" • ")) }
            SectionCard { H2("Services"); p.services.forEach { Body("• $it") } }
            SectionCard { H2("Service Areas"); p.serviceAreas.forEach { Body("• $it") } }
            SectionCard { H2("Contact on WhatsApp"); Body("Contact this provider using the submitted WhatsApp number."); Button({ openUrl(context, "https://wa.me/${normalizePakistanNumber(p.whatsappNumber)}") }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = p.whatsappNumber.any(Char::isDigit), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(Green)) { Text("◉  Contact on WhatsApp  ›", color = Color.White, fontWeight = FontWeight.Bold) } }
            SectionCard { H2("Ratings & Reviews"); Body("Ratings and reviews are not available yet.") }
        }
    }
}

@Composable private fun ProfileScreen(c: AppController) {
    val a = c.account
    Page(if (a?.isAdmin == true) "Admin Profile" else "Profile", { c.go(AppRoute.Home) }) {
        SectionCard { H2(a?.fullName.orEmpty()); Body(a?.email.orEmpty()); if (a?.isAdmin == true) Text("Admin", color = Pink) }
        H2("Beauty Services")
        when (val s = c.beautyState) { OwnerBeautyState.NoProfile -> StateEntry("Create Beauty Profile", "Offer your beauty services through a professional Beauty Profile on HerDay.") { c.enterCreateOrExisting() }; is OwnerBeautyState.Pending -> StateEntry(s.profile.professionalName, "Pending Review — Your Beauty Profile verification is awaiting HerDay review.") { c.go(AppRoute.Pending) }; is OwnerBeautyState.NeedsCorrection -> StateEntry(s.profile.professionalName, "Needs Correction") { c.enterCreateOrExisting() }; is OwnerBeautyState.Approved -> StateEntry(s.profile.professionalName, "Verified ✓") { c.go(AppRoute.MyBeauty) }; is OwnerBeautyState.Draft -> StateEntry("Continue Beauty Profile", "Finish your existing draft.") { c.enterCreateOrExisting() }; else -> Body("Beauty Profile state is loading or unavailable.") }
        if (a?.isAdmin == true) PrimaryButton("Admin Tools") { c.go(AppRoute.Admin) }
        OutlinedButton(c::logout, Modifier.fillMaxWidth()) { Text("Sign Out", color = Pink) }
    }
}

@Composable private fun AdminScreen(c: AppController) { Page("Admin Profile", { c.go(AppRoute.Profile) }) { SectionCard { H2(c.account?.fullName.orEmpty()); Body(c.account?.email.orEmpty()); Text("Admin", color = Pink) }; H2("Admin Tools"); StateEntry("Beauty Services", "Beauty Verifications — Review submitted Beauty Profiles.") { c.loadAdminPending() }; listOf("Moderation", "Users", "Reports & Safety", "Shop", "Content & Explore", "Advertising").forEach { SectionCard { H2(it); Body("Future management module.") } } } }

@Composable private fun AdminPendingScreen(c: AppController) { Page("Beauty Verifications", { c.go(AppRoute.Admin) }) { if (c.pending.isEmpty()) SectionCard { Body("No pending Beauty Profile verifications.") } else c.pending.forEach { p -> SectionCard(Modifier.clickable { c.openAdminReview(p) }) { H2(p.professionalName); Body("Pending Review"); Text("Open Review ›", color = Pink) } } } }

@Composable private fun AdminReviewScreen(c: AppController) {
    val p = c.selectedProvider ?: return
    var checks by remember(p.id) { mutableStateOf(List(4) { false }) }; var correctionMode by remember { mutableStateOf(false) }; var reason by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    Page("Beauty Verification Review", { c.go(AppRoute.AdminPending) }) {
        SectionCard { H2("Professional Profile"); PrivateBeautyPhoto(c, p.professionalPhotoPath); H2(p.professionalName); Body(p.about) }
        SectionCard { H2("Beauty Categories"); Body(p.categories.joinToString(" • ")) }
        SectionCard { H2("Services"); p.services.forEach { Body("• $it") } }
        SectionCard { H2("Service Areas"); p.serviceAreas.forEach { Body("• $it") } }
        SectionCard { H2("WhatsApp Number"); Body(p.whatsappNumber) }
        SectionCard { H2("Voice Verification Check"); listOf("WhatsApp number matches", "Professional / Parlor Name matches", "Services match", "Service Areas match").forEachIndexed { i, label -> Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checks[i], { value -> checks = checks.toMutableList().also { it[i] = value } }); Text(label, color = Plum) } } }
        if (!correctionMode) { PrimaryButton("Approve & Verify", checks.all { it }) { c.approve(p, checks) }; OutlinedButton({ correctionMode = true }, Modifier.fillMaxWidth()) { Text("Needs Correction", color = Pink) } }
        else SectionCard { H2("Needs Correction"); correctionReasons.forEach { r -> Row(Modifier.clickable { reason = r }, verticalAlignment = Alignment.CenterVertically) { RadioButton(reason == r, { reason = r }); Text(r, color = Plum) } }; LabeledField("Admin Note (Optional)", note, { if (it.length <= 300) note = it }, "Maximum 300 characters", singleLine = false); PrimaryButton("Send for Correction", reason.isNotBlank()) { c.correction(p, reason, note.ifBlank { null }) } }
    }
}

private fun normalizePakistanNumber(raw: String): String {
    val digits = raw.filter(Char::isDigit)
    return when { digits.startsWith("92") -> digits; digits.startsWith("0") -> "92${digits.drop(1)}"; else -> digits }
}
private fun beautyCategoryDrawable(category: String): Int = when (category) {
    "Makeup" -> R.drawable.beauty_category_makeup
    "Bridal Services" -> R.drawable.beauty_category_bridal_services
    "Hair" -> R.drawable.beauty_category_hair
    "Mehndi" -> R.drawable.beauty_category_mehndi
    "Skin & Facial" -> R.drawable.beauty_category_skin_facial
    "Waxing" -> R.drawable.beauty_category_waxing
    "Threading & Brows" -> R.drawable.beauty_category_threading_brows
    "Nails" -> R.drawable.beauty_category_nails
    "Manicure & Pedicure" -> R.drawable.beauty_category_manicure_pedicure
    "Lashes" -> R.drawable.beauty_category_lashes
    "Massage & Relaxation" -> R.drawable.beauty_category_massage_relaxation
    "Other Beauty Services" -> R.drawable.beauty_category_other_beauty_services
    else -> error("Unknown Beauty category: $category")
}
private fun openUrl(context: android.content.Context, url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }

@Composable private fun PrivateBeautyPhoto(c: AppController, path: String?) {
    if (path.isNullOrBlank()) return
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, path) {
        value = runCatching {
            val signed = c.api.signedBeautyPhotoUrl(path)
            withContext(Dispatchers.IO) { URL(signed).openStream().use { BitmapFactory.decodeStream(it) }?.asImageBitmap() }
        }.getOrNull()
    }
    bitmap?.let { Image(it, "Professional photo", Modifier.fillMaxWidth().height(210.dp), contentScale = ContentScale.Crop) }
}
