package com.herday.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/** One-shot native location acquisition. It never fabricates or substitutes an area. */
object NearMeLocation {
    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun acquire(
        context: Context,
        onLocation: (Location) -> Unit,
        onUnavailable: (String) -> Unit
    ) {
        if (!hasPermission(context)) {
            onUnavailable("Location permission is required to use Near Me.")
            return
        }
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (manager == null) {
            onUnavailable("Location is unavailable on this device.")
            return
        }
        val enabled = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if (enabled.isEmpty()) {
            onUnavailable("Turn on device location and try Near Me again.")
            return
        }

        val last = enabled.mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time <= 10 * 60 * 1000L) {
            onLocation(last)
            return
        }

        val handler = Handler(Looper.getMainLooper())
        var delivered = false
        lateinit var listener: LocationListener
        val finish: (Location?) -> Unit = { location ->
            if (!delivered) {
                delivered = true
                runCatching { manager.removeUpdates(listener) }
                if (location != null) onLocation(location)
                else if (last != null) onLocation(last)
                else onUnavailable("Current location could not be obtained. Please retry or choose a location.")
            }
        }
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) = finish(location)
            override fun onProviderDisabled(provider: String) = Unit
            override fun onProviderEnabled(provider: String) = Unit
            @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
        }
        try {
            enabled.forEach { manager.requestLocationUpdates(it, 0L, 0f, listener, Looper.getMainLooper()) }
            handler.postDelayed({ finish(null) }, 12_000L)
        } catch (_: SecurityException) {
            finish(null)
        } catch (_: IllegalArgumentException) {
            finish(null)
        }
    }
}
