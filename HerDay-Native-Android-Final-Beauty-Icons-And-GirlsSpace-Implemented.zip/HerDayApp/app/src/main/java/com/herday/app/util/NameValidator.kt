package com.herday.app.util

import com.ibm.icu.lang.UCharacter
import com.ibm.icu.lang.UCharacterCategory
import com.ibm.icu.lang.UScript
import com.ibm.icu.text.BreakIterator

/**
 * Deterministic Hero display-name validation, implementing the CURRENT
 * (Roman/Latin-only user-name) contracts in:
 *   #23 Approved-Name-Script-Validation-And-Urdu-Font-Policy-FINAL-Spec.json
 *   #26 Approved-Urdu-Noto-Metrics-And-Name-Validation-FINAL-Spec.json
 *
 * User/Hero display names now accept ONLY the Latin/Roman repertoire.
 * Urdu/Arabic-script (and Hindi/Bengali/other non-Latin script) user names
 * are rejected here. This restriction is scoped to USER NAMES only — it
 * says nothing about future multilingual CONTENT (posts, poetry, Explore
 * text, etc.), which is a separate, not-yet-built system.
 *
 * Per #23's implementation_determinism block, ALL classification decisions
 * here — whitespace/trim, script, Script_Extensions, grapheme clusters —
 * use bundled ICU4J 78.3 only (com.ibm.icu.*). `java.lang.Character`,
 * Kotlin's default `String.trim()`, `android.icu`, and the platform
 * `BreakIterator` are never used. The bundled-font glyph gate is a direct
 * TTF cmap membership check ([TtfCmap]), not `Paint.hasGlyph()`.
 */

sealed class NameValidationResult {
    data class Valid(val trimmed: String) : NameValidationResult()
    data class Rejected(val reason: String) : NameValidationResult()
}

private const val HYPHEN_MINUS = 0x002D
private const val APOSTROPHE = 0x0027

object NameValidator {

    /** ICU4J-only leading/trailing whitespace trim (never Kotlin's String.trim()). */
    private fun icuTrim(text: String): String {
        val codePoints = text.codePoints().toArray()
        var start = 0
        var end = codePoints.size
        while (start < end && UCharacter.isWhitespace(codePoints[start])) start++
        while (end > start && UCharacter.isWhitespace(codePoints[end - 1])) end--
        if (start == 0 && end == codePoints.size) return text
        val sb = StringBuilder()
        for (i in start until end) sb.appendCodePoint(codePoints[i])
        return sb.toString()
    }

    /** #23/#26 grapheme-cluster counter, ICU4J only. */
    fun graphemeClusterCount(text: String): Int {
        val bi = BreakIterator.getCharacterInstance()
        bi.setText(text)
        var count = 0
        var end = bi.next()
        while (end != BreakIterator.DONE) {
            count++
            end = bi.next()
        }
        return count
    }

    private fun graphemeClusters(text: String): List<String> {
        val bi = BreakIterator.getCharacterInstance()
        bi.setText(text)
        val out = mutableListOf<String>()
        var start = bi.first()
        var end = bi.next()
        while (end != BreakIterator.DONE) {
            out.add(text.substring(start, end))
            start = end
            end = bi.next()
        }
        return out
    }

    /**
     * Validates one individual First Name or Second/Last Name field against
     * the current Latin-only #23/#26 repertoire + bundled Kalam-Bold cmap gate.
     *
     * [fieldCmap] must be the bundled Kalam-Bold cmap — the only Hero-name
     * font now — so validation and rendering agree per #23's
     * bundled_font_glyph_gate.
     */
    fun validateField(
        raw: String,
        fieldCmap: TtfCmap,
        maxGraphemeClusters: Int = 12
    ): NameValidationResult {
        if (!IcuVersionGuard.isValid) {
            // #23 runtime_guard: fail closed rather than silently using
            // another Unicode behavior if the locked ICU4J/Unicode data
            // version contract is not satisfied on this build.
            return NameValidationResult.Rejected("icu_version_guard_failed")
        }

        val trimmed = icuTrim(raw)
        if (trimmed.isEmpty()) {
            return NameValidationResult.Rejected("empty")
        }

        val codePoints = trimmed.codePoints().toArray()

        // Internal whitespace inside one field is not permitted (#26),
        // checked via ICU4J only.
        if (codePoints.any { UCharacter.isWhitespace(it) }) {
            return NameValidationResult.Rejected("internal_whitespace")
        }

        // Pass 1: every BASE (non-mark, non-separator) character must be
        // Latin script. Any other script (Arabic/Devanagari/Bengali/etc.)
        // is rejected outright — there is no longer a second accepted
        // script family to route to.
        var sawBaseLetter = false
        for (cp in codePoints) {
            if (cp == HYPHEN_MINUS || cp == APOSTROPHE) continue

            val category = UCharacter.getType(cp)
            val isCombiningMark = category == UCharacterCategory.NON_SPACING_MARK.toInt() ||
                category == UCharacterCategory.ENCLOSING_MARK.toInt() ||
                category == UCharacterCategory.COMBINING_SPACING_MARK.toInt()
            if (isCombiningMark) continue // marks are resolved in pass 2

            if (UCharacter.isDigit(cp)) return NameValidationResult.Rejected("digit")
            if (!UCharacter.isLetter(cp)) return NameValidationResult.Rejected("unsupported_symbol_or_emoji")

            if (UScript.getScript(cp) != UScript.LATIN) {
                return NameValidationResult.Rejected("unsupported_script")
            }
            sawBaseLetter = true
        }
        if (!sawBaseLetter) return NameValidationResult.Rejected("no_script_detected")

        // Pass 2: combining marks are allowed only when their Script_Extensions
        // include Latin, or they are Common/Inherited, per #23.
        for (cp in codePoints) {
            if (cp == HYPHEN_MINUS || cp == APOSTROPHE) continue
            val category = UCharacter.getType(cp)
            val isCombiningMark = category == UCharacterCategory.NON_SPACING_MARK.toInt() ||
                category == UCharacterCategory.ENCLOSING_MARK.toInt() ||
                category == UCharacterCategory.COMBINING_SPACING_MARK.toInt()
            if (!isCombiningMark) continue

            val script = UScript.getScript(cp)
            val extensionsOk = UScript.hasScript(cp, UScript.LATIN)
            val commonOrInherited = script == UScript.COMMON || script == UScript.INHERITED
            if (!extensionsOk && !commonOrInherited) {
                return NameValidationResult.Rejected("unsupported_combining_mark")
            }
        }

        // #23 bundled_font_glyph_gate: every accepted Unicode scalar,
        // separators included, must be present in the bundled Kalam-Bold's
        // OWN cmap (direct TTF parse — no Paint.hasGlyph / system fallback).
        var clusterCount = 0
        for (cluster in graphemeClusters(trimmed)) {
            for (cp in cluster.codePoints().toArray()) {
                if (!fieldCmap.hasCodePoint(cp)) {
                    return NameValidationResult.Rejected("missing_glyph_in_bundled_font")
                }
            }
            clusterCount++
        }

        if (clusterCount > maxGraphemeClusters) {
            return NameValidationResult.Rejected("exceeds_max_characters")
        }

        return NameValidationResult.Valid(trimmed)
    }

    /**
     * #22 line_assignment_contract: counts First + one generated U+0020
     * SPACE + Second/Last as Unicode extended grapheme clusters (the
     * generated space counts as exactly 1), and reports whether the
     * combined result fits on Line 1 alone.
     */
    fun combinedLine1GraphemeCount(first: String, second: String?): Int {
        if (second.isNullOrEmpty()) return graphemeClusterCount(first)
        return graphemeClusterCount(first) + 1 /* generated U+0020 */ + graphemeClusterCount(second)
    }
}
