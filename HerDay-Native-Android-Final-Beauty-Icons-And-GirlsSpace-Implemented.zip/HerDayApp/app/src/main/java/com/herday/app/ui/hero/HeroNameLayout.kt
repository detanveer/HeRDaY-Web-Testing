package com.herday.app.ui.hero

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.herday.app.ui.theme.HeroTextColor
import com.herday.app.ui.theme.KalamBold
import kotlin.math.max
import kotlin.math.min

/**
 * Font metrics locked by #10/#12 (Kalam). Hero/user names are Latin/Roman
 * only (Kalam-Bold) per the current #22/#23/#26 product decision — Urdu
 * Nastaliq Hero-name routing, mixed-script paragraphs, and the associated
 * Noto ascent/baseline calculations have been removed as obsolete. This is
 * a USER-NAME restriction only; it says nothing about future multilingual
 * CONTENT (posts, poetry, etc.), which is a separate, not-yet-built system
 * and may use Noto/other scripts with its own font/shaping pipeline later.
 */
internal object FontMetrics {
    // #10/#12: Kalam UPEM 1000, ascent 1063, descent -531, lineGap 0.
    const val KALAM_UPEM = 1000
    const val KALAM_ASCENT = 1063
    const val KALAM_DESCENT = 531

    /**
     * Two-line vertical advance (line-1-baseline to line-2-baseline),
     * DERIVED from Kalam-Bold's actual rendered ink — not the font's full
     * nominal hhea ascent+descent box, which reserves far more vertical
     * room than any real name's glyphs occupy and was producing a visibly
     * oversized gap between line 1 and line 2.
     *
     * Measured directly (HarfBuzz/raqm shaping via Pillow) across a set of
     * representative real names exercising both tall ascenders and deep
     * descenders (Tanveer, Nawaz, Abigail, Jyoti, Priyanka, Gulzar,
     * Yasmin, Kalpana): worst-case ink spans from -47 to +16 relative to
     * baseline at size 58 (ratio 0.810 above baseline + 0.276 below =
     * 1.086 total), and -31 to +10 at size 38 (ratio 1.079) — confirming
     * near-linear scaling across the full 58->38 fitting range.
     *
     * Stacking two lines with EXACTLY that ink-to-ink distance (zero gap)
     * would already guarantee no glyph overlap; a further ~0.15 of font
     * size is added as conventional single-line breathing room (a
     * standard typographic minimum-leading margin), giving a
     * still-provably-safe but visibly compact two-line block rather than
     * either a cramped zero-gap stack or the old ~93%-oversized nominal
     * line-height.
     */
    const val KALAM_COMPACT_TWO_LINE_ADVANCE_FACTOR = 1.24f // (worst-case ink ratio 1.086) + (0.15 breathing margin)

    fun naturalAdvanceMasterPx(fontSizeMasterPx: Float): Float =
        KALAM_COMPACT_TWO_LINE_ADVANCE_FACTOR * fontSizeMasterPx

    /**
     * Kalam ascent, master px, per #10/#12's ascent formula. `internal`
     * (not `private`) so HeroSection.kt can reuse it for greeting/subtitle
     * ascender-anchor placement.
     */
    fun ascentMasterPx(fontSizeMasterPx: Float): Float = (KALAM_ASCENT.toFloat() / KALAM_UPEM) * fontSizeMasterPx
}

/** Master-space (Hero-local, 972x500) geometry constants from #05/#06/#22. */
object HeroNameSpec {
    const val PREFERRED_FONT_PX = 58f
    const val MINIMUM_FONT_PX = 38f
    const val NAME_LAYOUT_WIDTH_PX = 390f
    const val NAME_X = 58f
    const val LINE1_ASCENDER_ANCHOR_Y = 186f
    const val GREETING_X = 58f
    const val GREETING_ASCENDER_ANCHOR_Y = 136f
    const val GREETING_FONT_PX = 41f
    const val SUBTITLE_X = 60f
    const val SUBTITLE_BASE_Y = 262f
    const val SUBTITLE_FONT_PX = 25f
    const val BASE_MASK_RIGHT = 369f
    const val FACE_SAFE_MASK_RIGHT_CAP = 478f
    const val MASK_LEFT = 29f
    const val MASK_TOP = 91f
    const val BASE_MASK_HEIGHT = 208f
    const val MASK_READABILITY_PADDING = 30f
    const val COMBINED_LINE1_GRAPHEME_LIMIT = 12
}

private fun kalamStyle(sizeSp: TextUnit): SpanStyle = SpanStyle(
    color = HeroTextColor,
    fontSize = sizeSp,
    fontFamily = KalamBold,
    letterSpacing = 0.sp
)

/**
 * Result of laying out the Hero's dynamic display name. [line1DrawTopLeftYPx]
 * / [line2DrawTopLeftYPx] are already-corrected RUNTIME-PIXEL Canvas
 * `topLeft.y` values: each is computed as
 * `(ascenderAnchorYMaster + kalamAscentMaster) * runtimeScale - result.firstBaseline`,
 * so drawing each [TextLayoutResult] at that y lands its ACTUAL baseline
 * exactly on the approved formula's baseline, not on Compose's default
 * paragraph top-edge placement.
 */
data class HeroNameLayoutResult(
    val lineCount: Int,
    val finalFontSizeMasterPx: Float,
    val line1: TextLayoutResult,
    val line1DrawTopLeftYPx: Float,
    val line2: TextLayoutResult?,
    val line2DrawTopLeftYPx: Float?,
    val extraNameHeightMasterPx: Float,
    val dynamicMaskRightMasterPx: Float
)

/**
 * Implements (Kalam-only, current #22/#26):
 *  - line_assignment_contract (combined <=12 grapheme clusters -> one
 *    line; otherwise First on line 1, Second/Last on line 2)
 *  - two_line_shared_fit_contract (one common fitted size, 58..38) with
 *    directional End ellipsis at the minimum size (never silent Clip)
 *  - actual_aligned_bounds_contract + face_safe_horizontal_boundary,
 *    using TextLayoutResult.getLineRight(0) — the ACTUAL rendered/aligned
 *    line bound — never the fixed 390px layout-box width
 *  - authoritative extraNameHeight / two-line vertical placement
 *
 * [runtimeScale] is the uniform Hero-local scale `s` from #18
 * (runtimeHeroWidthPx / 972), already in the PIXEL domain (see HeroSection's
 * `sPx`). [masterPxToSp] converts master-px -> sp per #06's
 * compose_sp_conversion rule (px run through LocalDensity, not multiplied
 * by fontScale a second time).
 */
fun layoutHeroName(
    textMeasurer: TextMeasurer,
    firstName: String,
    secondName: String?,
    runtimeScale: Float,
    masterPxToSp: (Float) -> TextUnit
): HeroNameLayoutResult {

    val hasSecond = !secondName.isNullOrEmpty()
    val combinedGraphemeCount = com.herday.app.util.NameValidator.combinedLine1GraphemeCount(firstName, secondName)
    val bothOnLine1 = hasSecond && combinedGraphemeCount <= HeroNameSpec.COMBINED_LINE1_GRAPHEME_LIMIT
    val twoLines = hasSecond && !bothOnLine1

    fun runtimeMaxWidthPx() = HeroNameSpec.NAME_LAYOUT_WIDTH_PX * runtimeScale

    /**
     * Builds ONE explicit no-wrap line at [sizeMasterPx]. Since both fields
     * are always Kalam now, a combined Line-1 (First+SPACE+Second) is one
     * plain single-style run — no per-field spans/script-splitting needed.
     */
    fun buildLine(text: String, secondText: String? = null, sizeMasterPx: Float): AnnotatedString {
        val sizeSp = masterPxToSp(sizeMasterPx)
        val content = if (secondText != null) "$text $secondText" else text
        return buildAnnotatedString {
            withStyle(ParagraphStyle(textDirection = TextDirection.ContentOrLtr, textAlign = TextAlign.Start)) {
                withStyle(kalamStyle(sizeSp)) { append(content) }
            }
        }
    }

    fun measure(content: AnnotatedString, maxWidthPx: Int, overflow: TextOverflow): TextLayoutResult {
        return textMeasurer.measure(
            text = content,
            constraints = Constraints(maxWidth = maxWidthPx),
            style = TextStyle(
                textAlign = TextAlign.Start,
                // #11 include_font_padding lock: false, everywhere Hero text is measured/rendered.
                platformStyle = PlatformTextStyle(includeFontPadding = false)
            ),
            softWrap = false,
            maxLines = 1,
            overflow = overflow
        )
    }

    val maxWidthPx = runtimeMaxWidthPx().toInt().coerceAtLeast(1)

    /** #22/#15: intrinsic rendered width of a line, independent of Start-alignment box position. */
    fun measuredTextWidthPx(result: TextLayoutResult): Float = result.getLineRight(0) - result.getLineLeft(0)

    /**
     * #15 locked fitting algorithm (exact floating-point ratio, never an
     * integer 1px-decrement search):
     *   1. Measure at 58.
     *   2. If it fits, keep 58.
     *   3. Else fittedMasterPx = max(38, 58 * 390 / measuredMasterEquivalentWidthAt58),
     *      kept in floating point, shared across both lines when two lines exist
     *      (#22 two_line_shared_fit_contract: take the more restrictive of the
     *      two lines' own candidate sizes).
     *   4. Re-measure at the exact floating-point fitted size with the same
     *      pipeline; if a per-line non-linearity still leaves it overflowing
     *      above the 38 floor, refine downward with a bounded floating-point
     *      bisection (never integer steps) instead of assuming the linear
     *      ratio is exact.
     *   5. Only once at (or clamped to) 38 and still overflowing does
     *      directional End ellipsis apply.
     */
    fun candidateSizeForLine(text: String, secondText: String?): Float {
        val at58 = measure(buildLine(text, secondText, HeroNameSpec.PREFERRED_FONT_PX), maxWidthPx, TextOverflow.Clip)
        if (!at58.didOverflowWidth) return HeroNameSpec.PREFERRED_FONT_PX
        val widthAt58Master = measuredTextWidthPx(at58) / runtimeScale
        if (widthAt58Master <= 0f) return HeroNameSpec.PREFERRED_FONT_PX
        val ratioFitted = HeroNameSpec.PREFERRED_FONT_PX * HeroNameSpec.NAME_LAYOUT_WIDTH_PX / widthAt58Master
        return ratioFitted.coerceIn(HeroNameSpec.MINIMUM_FONT_PX, HeroNameSpec.PREFERRED_FONT_PX)
    }

    val line1RatioCandidate = if (bothOnLine1) {
        candidateSizeForLine(firstName, secondName)
    } else {
        candidateSizeForLine(firstName, null)
    }
    val line2RatioCandidate = if (twoLines) candidateSizeForLine(secondName!!, null) else null

    var chosenSize = listOfNotNull(line1RatioCandidate, line2RatioCandidate).min()

    fun measureBoth(size: Float, overflow: TextOverflow): Pair<TextLayoutResult, TextLayoutResult?> {
        val l1 = if (bothOnLine1) {
            measure(buildLine(firstName, secondName, size), maxWidthPx, overflow)
        } else {
            measure(buildLine(firstName, sizeMasterPx = size), maxWidthPx, overflow)
        }
        val l2 = if (twoLines) {
            measure(buildLine(secondName!!, sizeMasterPx = size), maxWidthPx, overflow)
        } else null
        return l1 to l2
    }

    var (line1Result, line2Result) = measureBoth(chosenSize, TextOverflow.Clip)

    // Floating-point safety-net refinement: the 58->fittedSize ratio assumes
    // roughly linear glyph-width scaling, which real font hinting/kerning can
    // violate slightly. If the ratio-based candidate still overflows above
    // the 38 floor, bisect (in floating point, not integer steps) down to a
    // size that fits, or down to 38 if none does.
    if ((line1Result.didOverflowWidth || line2Result?.didOverflowWidth == true) && chosenSize > HeroNameSpec.MINIMUM_FONT_PX) {
        var low = HeroNameSpec.MINIMUM_FONT_PX
        var high = chosenSize
        repeat(12) {
            val mid = (low + high) / 2f
            val (l1, l2) = measureBoth(mid, TextOverflow.Clip)
            if (l1.didOverflowWidth || l2?.didOverflowWidth == true) {
                high = mid
            } else {
                low = mid
            }
        }
        chosenSize = low
        val (l1, l2) = measureBoth(chosenSize, TextOverflow.Clip)
        line1Result = l1
        line2Result = l2
    }

    // Final pass: if content still overflows at (or clamped to) the minimum
    // size, re-measure with the approved End ellipsis — never leave a
    // silently Clipped result.
    if (line1Result.didOverflowWidth) {
        line1Result = if (bothOnLine1) {
            measure(buildLine(firstName, secondName, chosenSize), maxWidthPx, TextOverflow.Ellipsis)
        } else {
            measure(buildLine(firstName, sizeMasterPx = chosenSize), maxWidthPx, TextOverflow.Ellipsis)
        }
    }
    if (line2Result?.didOverflowWidth == true) {
        line2Result = measure(buildLine(secondName!!, sizeMasterPx = chosenSize), maxWidthPx, TextOverflow.Ellipsis)
    }

    val extraNameHeight: Float
    val line1AnchorY = HeroNameSpec.LINE1_ASCENDER_ANCHOR_Y
    var line2AnchorY: Float? = null

    if (twoLines) {
        val line1Advance = FontMetrics.naturalAdvanceMasterPx(chosenSize)
        val line2Advance = FontMetrics.naturalAdvanceMasterPx(chosenSize)
        // #26 authoritative_two_line_extra_name_height_contract:
        extraNameHeight = max(line1Advance, line2Advance)
        // #22 second_line_placement_and_height_contract: anchor offset uses line 1's own advance.
        line2AnchorY = line1AnchorY + line1Advance
    } else {
        extraNameHeight = 0f
    }

    val line1AscentMaster = FontMetrics.ascentMasterPx(chosenSize)
    val line1BaselineMasterPx = line1AnchorY + line1AscentMaster
    val line1DrawTopLeftYPx = line1BaselineMasterPx * runtimeScale - line1Result.firstBaseline

    val line2DrawTopLeftYPx: Float? = if (twoLines && line2Result != null && line2AnchorY != null) {
        val line2AscentMaster = FontMetrics.ascentMasterPx(chosenSize)
        val line2BaselineMasterPx = line2AnchorY + line2AscentMaster
        line2BaselineMasterPx * runtimeScale - line2Result.firstBaseline
    } else null

    // #22 actual_aligned_bounds_contract + face_safe_horizontal_boundary:
    // mask right derives from the farther-right ACTUAL RENDERED/ALIGNED
    // bound of whichever line(s) exist — TextLayoutResult.getLineRight(0),
    // never the fixed 390px layout-box width and never size.width (which
    // reflects the constrained box, not the visible glyph run).
    fun lineRightMasterPx(result: TextLayoutResult): Float {
        val alignedRightPx = result.getLineRight(0)
        return HeroNameSpec.NAME_X + alignedRightPx / runtimeScale
    }

    val actualRight = if (twoLines) {
        max(lineRightMasterPx(line1Result), lineRightMasterPx(line2Result!!))
    } else {
        lineRightMasterPx(line1Result)
    }
    val requiredMaskRight = actualRight + HeroNameSpec.MASK_READABILITY_PADDING
    val dynamicMaskRight = min(
        max(HeroNameSpec.BASE_MASK_RIGHT, requiredMaskRight),
        HeroNameSpec.FACE_SAFE_MASK_RIGHT_CAP
    )

    return HeroNameLayoutResult(
        lineCount = if (twoLines) 2 else 1,
        finalFontSizeMasterPx = chosenSize,
        line1 = line1Result,
        line1DrawTopLeftYPx = line1DrawTopLeftYPx,
        line2 = line2Result,
        line2DrawTopLeftYPx = line2DrawTopLeftYPx,
        extraNameHeightMasterPx = extraNameHeight,
        dynamicMaskRightMasterPx = dynamicMaskRight
    )
}
