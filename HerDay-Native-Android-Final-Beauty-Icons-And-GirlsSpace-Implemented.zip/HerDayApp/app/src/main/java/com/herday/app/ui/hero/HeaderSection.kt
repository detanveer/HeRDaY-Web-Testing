package com.herday.app.ui.hero

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import com.herday.app.R

/**
 * Header geometry registered inside the approved 882-unit foreground frame.
 */
@Composable
fun HeaderSection(s: Float, modifier: Modifier = Modifier) {
    val headerHeight: Dp = Dp(84 * s)
    Box(
        modifier = modifier.size(width = Dp(882 * s), height = headerHeight)
    ) {
        // Preserve the approved logo registration relative to the old
        // content origin: 131 - 97 = 34 foreground units.
        Image(
            painter = painterResource(R.drawable.logo_herday),
            contentDescription = stringResource(R.string.herday_logo_content_description),
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .offset(x = Dp(34 * s), y = Dp(27 * s))
                .size(width = Dp(180 * s), height = Dp(57 * s))
        )

        // Preserve the approved bell registration relative to that same
        // content origin: 880 - 97 = 783 foreground units.
        Image(
            painter = painterResource(R.drawable.ic_notification_bell_final),
            contentDescription = stringResource(R.string.notification_bell_content_description),
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .offset(x = Dp(783 * s), y = Dp(18 * s))
                .size(Dp(74 * s))
        )
    }
}
