package com.herday.app.util

import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Minimal TrueType `cmap` table reader that resolves the ACTUAL glyph ID
 * for a code point — not merely "does this code point fall inside a
 * declared segment/range" — and rejects glyph ID 0 (`.notdef`) as
 * unsupported, per #23's bundled_font_glyph_gate.
 *
 * Supports format 4 (BMP, via the real idDelta/idRangeOffset algorithm)
 * and format 12 (full Unicode, `startGlyphId + (codePoint - startCharCode)`),
 * preferring the best available Unicode-platform subtable.
 */
class TtfCmap private constructor(
    /** Full BMP (0x0000..0xFFFF) glyph-id lookup, resolved via the real format-4 algorithm. 0 = unsupported. */
    private val bmpGlyphIds: IntArray?,
    /** Format-12 groups (supplementary planes and/or full-repertoire), each with its own startGlyphId. */
    private val format12Groups: List<Format12Group>
) {
    private data class Format12Group(val startCharCode: Int, val endCharCode: Int, val startGlyphId: Int)

    /** Resolves the actual glyph ID for [cp], or 0 (`.notdef`) if unmapped. */
    private fun resolveGlyphId(cp: Int): Int {
        if (bmpGlyphIds != null && cp in 0..0xFFFF) {
            return bmpGlyphIds[cp]
        }
        for (g in format12Groups) {
            if (cp in g.startCharCode..g.endCharCode) {
                return g.startGlyphId + (cp - g.startCharCode)
            }
        }
        return 0
    }

    /** #23 bundled_font_glyph_gate: true only if [cp] maps to a REAL glyph (not `.notdef`). */
    fun hasCodePoint(cp: Int): Boolean = resolveGlyphId(cp) != 0

    companion object {
        fun parse(input: InputStream): TtfCmap {
            val bytes = input.readBytes()
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)

            // sfnt header
            buf.position(4)
            val numTables = buf.short.toInt() and 0xFFFF
            buf.position(12) // skip searchRange/entrySelector/rangeShift

            var cmapOffset = -1
            repeat(numTables) {
                val tag = ByteArray(4).also { buf.get(it) }
                val tagStr = String(tag, Charsets.US_ASCII)
                buf.int // checksum
                val offset = buf.int
                buf.int // length
                if (tagStr == "cmap") cmapOffset = offset
            }
            require(cmapOffset >= 0) { "No cmap table in bundled font" }

            buf.position(cmapOffset)
            buf.short // version
            val numSubtables = buf.short.toInt() and 0xFFFF

            var bestOffset = -1
            var bestScore = -1
            repeat(numSubtables) {
                val platformId = buf.short.toInt() and 0xFFFF
                val encodingId = buf.short.toInt() and 0xFFFF
                val offset = buf.int
                // Prefer Windows/Unicode full-repertoire (3,10), then BMP (3,1),
                // then any Unicode platform (0,x).
                val score = when {
                    platformId == 3 && encodingId == 10 -> 3
                    platformId == 3 && encodingId == 1 -> 2
                    platformId == 0 -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    bestOffset = cmapOffset + offset
                }
            }
            require(bestOffset >= 0) { "No usable cmap subtable in bundled font" }

            buf.position(bestOffset)
            val format = buf.short.toInt() and 0xFFFF
            return when (format) {
                4 -> TtfCmap(parseFormat4(buf, bestOffset), emptyList())
                12 -> TtfCmap(null, parseFormat12(buf, bestOffset))
                else -> error("Unsupported cmap subtable format $format in bundled font")
            }
        }

        /**
         * Real format-4 algorithm: for each segment, resolves every code
         * point's ACTUAL glyph ID (not just "is it in range"):
         *   idRangeOffset == 0  -> glyphId = (codePoint + idDelta) & 0xFFFF
         *   idRangeOffset != 0  -> read a UInt16 from the glyphIdArray via
         *                          the standard TrueType pointer arithmetic;
         *                          0 there means .notdef; otherwise
         *                          glyphId = (value + idDelta) & 0xFFFF
         * Returns a full 65536-entry BMP lookup (0 = unsupported/.notdef).
         */
        private fun parseFormat4(buf: ByteBuffer, subtableOffset: Int): IntArray {
            buf.position(subtableOffset)
            buf.short // format (re-read defensively; already consumed by caller's peek)
            buf.short // length
            buf.short // language
            val segCountX2 = buf.short.toInt() and 0xFFFF
            val segCount = segCountX2 / 2
            buf.short // searchRange
            buf.short // entrySelector
            buf.short // rangeShift

            val endCodes = IntArray(segCount) { buf.short.toInt() and 0xFFFF }
            buf.short // reservedPad
            val startCodes = IntArray(segCount) { buf.short.toInt() and 0xFFFF }
            val idDeltas = IntArray(segCount) { buf.short.toInt() } // SIGNED Int16
            val idRangeOffsetPos = IntArray(segCount)
            val idRangeOffsets = IntArray(segCount) {
                idRangeOffsetPos[it] = buf.position()
                buf.short.toInt() and 0xFFFF
            }

            val glyphIds = IntArray(0x10000) // all zero (.notdef) by default

            for (i in 0 until segCount) {
                val start = startCodes[i]
                val end = endCodes[i]
                if (start == 0xFFFF && end == 0xFFFF) continue
                val idDelta = idDeltas[i]
                val idRangeOffset = idRangeOffsets[i]

                if (idRangeOffset == 0) {
                    for (c in start..end) {
                        glyphIds[c] = (c + idDelta) and 0xFFFF
                    }
                } else {
                    for (c in start..end) {
                        val glyphIndexAddress = idRangeOffsetPos[i] + idRangeOffset + 2 * (c - start)
                        val rawGlyphId = buf.getShort(glyphIndexAddress).toInt() and 0xFFFF
                        glyphIds[c] = if (rawGlyphId != 0) (rawGlyphId + idDelta) and 0xFFFF else 0
                    }
                }
            }
            return glyphIds
        }

        private fun parseFormat12(buf: ByteBuffer, subtableOffset: Int): List<Format12Group> {
            buf.position(subtableOffset)
            buf.short // format
            buf.short // reserved
            buf.int // length
            buf.int // language
            val numGroups = buf.int
            val groups = mutableListOf<Format12Group>()
            repeat(numGroups) {
                val startCharCode = buf.int
                val endCharCode = buf.int
                val startGlyphId = buf.int
                groups.add(Format12Group(startCharCode, endCharCode, startGlyphId))
            }
            return groups
        }
    }
}
