package com.herday.app.util

import com.ibm.icu.lang.UCharacter
import com.ibm.icu.util.VersionInfo

/**
 * #23 implementation_determinism.runtime_guard: at startup, assert the
 * bundled ICU4J runtime/data version matches the locked contract
 * (ICU4J 78.3 / Unicode data 17.0). If it does not, name validation must
 * fail CLOSED rather than silently fall back to platform Unicode
 * behavior — see [NameValidator]'s use of [IcuVersionGuard.isValid].
 */
object IcuVersionGuard {

    private const val EXPECTED_ICU_MAJOR = 78
    private const val EXPECTED_ICU_MINOR = 3
    private const val EXPECTED_UNICODE_MAJOR = 17
    private const val EXPECTED_UNICODE_MINOR = 0

    /** Computed once and cached; re-checked on demand via [check]. */
    val isValid: Boolean by lazy { check().ok }

    data class Result(val ok: Boolean, val detail: String)

    fun check(): Result {
        return try {
            val icuVersion = VersionInfo.ICU_VERSION
            val icuOk = icuVersion.major == EXPECTED_ICU_MAJOR && icuVersion.minor == EXPECTED_ICU_MINOR

            val unicodeVersion = UCharacter.getUnicodeVersion()
            val unicodeOk = unicodeVersion.major == EXPECTED_UNICODE_MAJOR &&
                unicodeVersion.minor == EXPECTED_UNICODE_MINOR

            if (icuOk && unicodeOk) {
                Result(true, "ICU4J ${icuVersion} / Unicode ${unicodeVersion} matches locked contract")
            } else {
                Result(
                    false,
                    "ICU4J/Unicode version mismatch: got ICU4J $icuVersion, Unicode $unicodeVersion; " +
                        "required ICU4J $EXPECTED_ICU_MAJOR.$EXPECTED_ICU_MINOR, " +
                        "Unicode $EXPECTED_UNICODE_MAJOR.$EXPECTED_UNICODE_MINOR"
                )
            }
        } catch (t: Throwable) {
            Result(false, "ICU4J version check failed: ${t.message}")
        }
    }
}
