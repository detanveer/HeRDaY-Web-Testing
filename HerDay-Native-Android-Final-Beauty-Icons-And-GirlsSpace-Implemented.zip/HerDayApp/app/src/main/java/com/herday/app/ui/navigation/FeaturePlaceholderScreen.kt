package com.herday.app.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herday.app.R
import com.herday.app.ui.theme.HomeBackground

enum class FeatureSection(val route: String, val title: String) {
    Poetry("poetry", "Poetry"),
    GirlsSpace("girls-space", "Girls' Space"),
    Explore("explore", "Explore"),
    DailyTools("daily-tools", "Daily Tools"),
    BeautyServices("beauty-services", "Beauty Services"),
    BuySell("buy-sell", "Buy & Sell"),
    DailyHoroscope("daily-horoscope", "Daily Horoscope"),
    Shop("shop", "Shop"),
    Community("community", "Community");

    companion object {
        fun fromRoute(route: String): FeatureSection? = entries.firstOrNull { it.route == route }
    }
}

private val DmSerif = FontFamily(Font(R.font.dm_serif_display_regular, FontWeight.Normal))
private val Poppins = FontFamily(Font(R.font.poppins_regular, FontWeight.Normal))

@Composable
fun FeaturePlaceholderScreen(section: FeatureSection, onBack: () -> Unit) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HomeBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        TextButton(onClick = onBack) {
            Text(
                text = "‹  Back",
                color = Color(0xFFC42767),
                fontFamily = Poppins,
                fontSize = 16.sp
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = section.title,
                color = Color(0xFF5F344F),
                fontFamily = DmSerif,
                fontSize = 32.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "This section is coming soon.\nWe're working on it.",
                color = Color(0xFF745B6B),
                fontFamily = Poppins,
                fontSize = 16.sp,
                lineHeight = 24.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
