package com.herday.app.ui.hero

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.herday.app.R
import com.herday.app.util.NameValidationResult
import com.herday.app.util.NameValidator
import com.herday.app.util.TtfCmap

/**
 * Correction-pass fix #8 (retained): this harness only ever gets composed
 * from `BuildConfig.DEBUG`-gated call sites (see HomeScreen.kt) — it
 * renders no layout space at all in release builds, not merely hidden
 * content.
 *
 * DEBUG-ONLY Phase 1 harness: lets a developer type different First/Second
 * names and see the approved Hero react (line assignment, fitting, dynamic
 * mask) without rebuilding anything. This is NOT the approved production
 * name-entry UI — no such screen exists yet. Replace/remove this harness
 * once a real profile/name-entry flow exists.
 *
 * Per the current #23/#26 product decision, user/Hero names are
 * Latin/Roman only — Urdu-script input (and other non-Latin scripts) is
 * validated and rejected here, exactly like any other unsupported script,
 * with no fallback attempt against a second font/script.
 */
@Composable
fun DebugNameHarness(
    onValidNames: (first: String, second: String?) -> Unit
) {
    val context = LocalContext.current
    // #23 bundled_font_glyph_gate: parsed directly from the bundled
    // Kalam-Bold TTF (see TtfCmap), never Paint.hasGlyph / system fallback.
    val kalamCmap = remember { TtfCmap.parse(context.resources.openRawResource(R.font.kalam_bold)) }

    var firstInput by remember { mutableStateOf("Tanveer") }
    var secondInput by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun tryApply() {
        val firstResult = NameValidator.validateField(firstInput, kalamCmap)
        if (firstResult !is NameValidationResult.Valid) {
            error = "first_name_invalid"
            return
        }
        if (secondInput.isBlank()) {
            error = null
            onValidNames(firstResult.trimmed, null)
            return
        }
        val secondResult = NameValidator.validateField(secondInput, kalamCmap)
        if (secondResult !is NameValidationResult.Valid) {
            error = "second_name_invalid"
            return
        }
        error = null
        onValidNames(firstResult.trimmed, secondResult.trimmed)
    }

    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(text = "Phase 1 debug (DEBUG builds only): Hero name harness — not production UI")
        OutlinedTextField(
            value = firstInput,
            onValueChange = { firstInput = it; tryApply() },
            label = { Text("First Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        OutlinedTextField(
            value = secondInput,
            onValueChange = { secondInput = it; tryApply() },
            label = { Text("Second / Last Name (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        if (error == "first_name_invalid" || error == "second_name_invalid") {
            Text(text = stringResource(R.string.name_validation_error))
        }
    }
}
