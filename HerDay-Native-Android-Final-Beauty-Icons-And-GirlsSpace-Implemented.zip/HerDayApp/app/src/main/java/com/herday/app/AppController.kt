package com.herday.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herday.app.data.*
import kotlinx.coroutines.launch

enum class AppRoute { Login, SignUp, Home, Placeholder, BeautyMain, BeautyCategories, BeautyEditor, VerifyInfo, Pending, MyBeauty, PublicBeauty, Profile, Admin, AdminPending, AdminReview }

class AppController(application: Application) : AndroidViewModel(application) {
    val api = SupabaseGateway(application)
    var route by mutableStateOf(if (api.session == null) AppRoute.Login else AppRoute.Home); private set
    var account by mutableStateOf<AccountProfile?>(null); private set
    var beautyState by mutableStateOf<OwnerBeautyState>(OwnerBeautyState.Loading); private set
    var providers by mutableStateOf<List<BeautyProfile>>(emptyList()); private set
    var pending by mutableStateOf<List<BeautyProfile>>(emptyList()); private set
    var locationSuggestions by mutableStateOf<List<String>>(emptyList()); private set
    var selectedBeautyArea by mutableStateOf<String?>(null); private set
    var selectedProvider by mutableStateOf<BeautyProfile?>(null); private set
    var placeholder by mutableStateOf<com.herday.app.ui.navigation.FeatureSection?>(null); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var uploadedBeautyPhotoPath by mutableStateOf<String?>(null); private set

    init { if (api.session != null) restore() }

    fun go(next: AppRoute) { route = next }
    fun openHomeFeature(section: com.herday.app.ui.navigation.FeatureSection) {
        if (section == com.herday.app.ui.navigation.FeatureSection.BeautyServices) enterBeauty()
        else { placeholder = section; route = AppRoute.Placeholder }
    }
    fun clearError() { error = null }
    private fun fail(t: Throwable) { error = t.message ?: "Something went wrong." }

    private fun restore() = viewModelScope.launch {
        busy = true
        val restored = runCatching { api.refreshSession() ?: api.session }
        if (restored.isSuccess) runCatching { loadAccountAndBeauty() }.onFailure(::fail) else logoutLocal()
        busy = false
    }

    fun login(email: String, password: String) = viewModelScope.launch {
        mutate { api.signIn(email.trim(), password); loadAccountAndBeauty(); route = AppRoute.Home }
    }

    fun signUp(first: String, last: String, email: String, cell: String?, password: String) = viewModelScope.launch {
        mutate { api.signUp(first.trim(), last.trim(), email.trim(), cell?.trim()?.takeIf(String::isNotEmpty), password); loadAccountAndBeauty(); route = AppRoute.Home }
    }

    suspend fun loadAccountAndBeauty() {
        account = api.accountProfile()
        if (account?.isBlocked == true) { api.signOut(); logoutLocal(); error = "This account is blocked."; return }
        resolveBeauty()
    }

    suspend fun resolveBeauty(): OwnerBeautyState {
        beautyState = OwnerBeautyState.Loading
        beautyState = runCatching { api.ownerBeautyProfile()?.toOwnerState() ?: OwnerBeautyState.NoProfile }
            .getOrElse { OwnerBeautyState.Error(it.message ?: "Could not load Beauty Profile.") }
        return beautyState
    }

    fun enterBeauty() = viewModelScope.launch { resolveBeauty(); route = AppRoute.BeautyMain; loadProviders() }

    fun enterCreateOrExisting() = viewModelScope.launch {
        when (resolveBeauty()) {
            OwnerBeautyState.NoProfile, is OwnerBeautyState.Draft, is OwnerBeautyState.NeedsCorrection -> route = AppRoute.BeautyEditor
            is OwnerBeautyState.Pending -> route = AppRoute.Pending
            is OwnerBeautyState.Approved -> route = AppRoute.MyBeauty
            is OwnerBeautyState.UnknownExisting -> error = "This Beauty Profile has an unsupported status. No new profile was created."
            is OwnerBeautyState.Error -> error = "Beauty Profile could not be checked. Please retry."
            OwnerBeautyState.Loading -> Unit
        }
    }

    fun enterVerifyInfo() = viewModelScope.launch {
        when (resolveBeauty()) {
            is OwnerBeautyState.Pending -> route = AppRoute.Pending
            is OwnerBeautyState.Approved -> route = AppRoute.MyBeauty
            is OwnerBeautyState.Draft, is OwnerBeautyState.NeedsCorrection -> route = AppRoute.VerifyInfo
            else -> error = "Complete your Beauty Profile first."
        }
    }

    fun saveBeauty(draft: BeautyDraft) = viewModelScope.launch {
        mutate {
            when (val current = resolveBeauty()) {
                OwnerBeautyState.NoProfile -> try {
                    api.createBeautyProfile(draft)
                } catch (e: SupabaseException) {
                    if (e.code == "23505") {
                        val resolved = resolveBeauty()
                        if (resolved is OwnerBeautyState.NoProfile) throw e
                    } else throw e
                }
                is OwnerBeautyState.Draft -> api.updateBeautyProfile(current.profile.id, draft)
                is OwnerBeautyState.NeedsCorrection -> api.updateBeautyProfile(current.profile.id, draft)
                is OwnerBeautyState.Pending -> { route = AppRoute.Pending; return@mutate }
                is OwnerBeautyState.Approved -> { route = AppRoute.MyBeauty; return@mutate }
                is OwnerBeautyState.UnknownExisting -> throw IllegalStateException("Unsupported existing profile status; creation is blocked.")
                is OwnerBeautyState.Error, OwnerBeautyState.Loading -> throw IllegalStateException("Authoritative Beauty Profile state is unavailable.")
            }
            when (resolveBeauty()) {
                is OwnerBeautyState.Pending -> route = AppRoute.Pending
                is OwnerBeautyState.Approved -> route = AppRoute.MyBeauty
                else -> route = AppRoute.VerifyInfo
            }
        }
    }

    fun submitVoiceConfirmation() = viewModelScope.launch {
        mutate {
            val state = resolveBeauty()
            val profile = when (state) {
                is OwnerBeautyState.Draft -> state.profile
                is OwnerBeautyState.NeedsCorrection -> state.profile
                is OwnerBeautyState.Pending -> { route = AppRoute.Pending; return@mutate }
                is OwnerBeautyState.Approved -> { route = AppRoute.MyBeauty; return@mutate }
                else -> throw IllegalStateException("No editable Beauty Profile found.")
            }
            api.submitVerification(profile.id); resolveBeauty(); route = AppRoute.Pending
        }
    }

    fun loadProviders(category: String? = null, area: String? = null) = viewModelScope.launch {
        runCatching { api.approvedProviders(category, area) }.onSuccess { providers = it }.onFailure(::fail)
    }
    fun searchLocations(query: String) = viewModelScope.launch { locationSuggestions = runCatching { api.searchPakistanLocations(query) }.getOrDefault(emptyList()) }
    fun useNearMe(latitude: Double, longitude: Double, category: String?) = viewModelScope.launch {
        mutate {
            val area = api.reversePakistanLocation(latitude, longitude)
            selectedBeautyArea = area
            providers = api.approvedProviders(category, area)
        }
    }
    fun showMessage(message: String) { error = message }
    fun selectBeautyArea(area: String, category: String?) = viewModelScope.launch {
        selectedBeautyArea = area
        locationSuggestions = emptyList()
        runCatching { api.approvedProviders(category, area) }.onSuccess { providers = it }.onFailure(::fail)
    }

    fun uploadBeautyPhoto(uri: Uri) = viewModelScope.launch {
        mutate {
            val resolver = getApplication<Application>().contentResolver
            val mime = resolver.getType(uri) ?: throw IllegalArgumentException("Unsupported image type.")
            val extension = when (mime) { "image/jpeg" -> "jpg"; "image/png" -> "png"; "image/webp" -> "webp"; else -> throw IllegalArgumentException("Use JPEG, PNG or WebP.") }
            val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalArgumentException("Could not read photo.")
            uploadedBeautyPhotoPath = api.uploadBeautyPhoto(bytes, extension, mime)
        }
    }

    fun openProvider(profile: BeautyProfile) { selectedProvider = profile; route = AppRoute.PublicBeauty }
    fun openAdminReview(profile: BeautyProfile) { selectedProvider = profile; route = AppRoute.AdminReview }
    fun loadAdminPending() = viewModelScope.launch { mutate { pending = api.pendingProfiles(); route = AppRoute.AdminPending } }
    fun approve(profile: BeautyProfile, checks: List<Boolean>) = viewModelScope.launch { mutate { require(checks.all { it }); api.approve(profile.id, checks); pending = api.pendingProfiles(); route = AppRoute.AdminPending } }
    fun correction(profile: BeautyProfile, reason: String, note: String?) = viewModelScope.launch { mutate { api.requestCorrection(profile.id, reason, note); pending = api.pendingProfiles(); route = AppRoute.AdminPending } }

    fun logout() = viewModelScope.launch { busy = true; runCatching { api.signOut() }; logoutLocal(); busy = false }
    private fun logoutLocal() { account = null; beautyState = OwnerBeautyState.Loading; providers = emptyList(); pending = emptyList(); locationSuggestions = emptyList(); selectedBeautyArea = null; selectedProvider = null; uploadedBeautyPhotoPath = null; placeholder = null; route = AppRoute.Login }

    private suspend fun mutate(block: suspend () -> Unit) {
        if (busy) return
        busy = true; error = null
        runCatching { block() }.onFailure(::fail)
        busy = false
    }
}
