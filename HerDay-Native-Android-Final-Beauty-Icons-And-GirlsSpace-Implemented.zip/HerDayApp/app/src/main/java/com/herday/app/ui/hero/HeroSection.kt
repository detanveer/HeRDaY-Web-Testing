package com.herday.app.ui.hero

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.herday.app.R
import com.herday.app.ui.theme.HeroTextColor
import com.herday.app.ui.theme.KalamRegular

/**
 * #08/#05/#06/#22 Hero: artwork -> outlined dynamic Hero text, clipped to
 * the approved 48-master-px rounded rectangle. [s] is the
 * uniform width-derived runtime scale from #18.
 *
 * [firstName]/[secondName] are a simple local/demo name state for Phase 1
 * (#09 of the implementation prompt) — no backend/profile exists yet. Any
 * name reaching this composable must already have passed NameValidator per
 * the current (Latin/Roman-only) #23/#26. There is no per-script routing
 * anymore — all Hero names render with Kalam-Bold.
 */
@Composable
fun HeroSection(
    s: Float,
    firstName: String,
    secondName: String?,
    modifier: Modifier = Modifier
) {
    val heroWidth = Dp(882 * s)
    val heroHeight = Dp(512 * s)
    val cornerRadius = Dp(20 * s)
    val density = LocalDensity.current

    // [s] is the internal Dp-domain scale of the centered foreground frame:
    // foregroundWidthDp / 882. Canvas
    // drawing and TextMeasurer both operate in true device pixels, so text
    // placement / sp-conversion must use the PIXEL-domain
    // equivalent is converted into the Hero's verified 972-unit text space.
    // Mixing the two domains was the
    // one place this implementation could silently drift from the approved
    // pixel-accurate formulas, so it is kept explicit and commented here.
    val sPx = s * density.density * (882f / 972f)
    val textMeasurer = rememberTextMeasurer()

    fun masterPxToSp(masterPx: Float): TextUnit {
        val runtimePx = masterPx * sPx
        return with(density) { runtimePx.toSp() }
    }

    val layout = remember(firstName, secondName, sPx) {
        layoutHeroName(
            textMeasurer = textMeasurer,
            firstName = firstName,
            secondName = secondName,
            runtimeScale = sPx,
            masterPxToSp = ::masterPxToSp
        )
    }

    // #10/#12: greeting/subtitle strings resolved here (composable scope);
    // the Canvas draw lambda below is NOT @Composable, so string resources
    // must be read out here and captured by closure, not called inside it.
    val greetingText = stringResource(R.string.hero_greeting)
    val subtitleText = stringResource(R.string.hero_subtitle)

    /**
     * #10/#12 coordinate_anchor fix: the approved Y for greeting/name/
     * subtitle is a FONT_ASCENDER_BOX_TOP anchor, never a Compose Text
     * layout-box top. This measures a single fixed-string Kalam-Regular
     * line and returns the exact `topLeft.y` (in runtime px) that places
     * its real baseline at `ascenderAnchorYMasterPx + kalamAscent(sizePx)`,
     * using the same firstBaseline-correction technique as the dynamic
     * name — never an invented/arbitrary compensation constant.
     */
    fun measureFixedLine(
        text: String,
        ascenderAnchorYMasterPx: Float,
        fontSizeMasterPx: Float
    ): Pair<androidx.compose.ui.text.TextLayoutResult, Float> {
        val result = textMeasurer.measure(
            text = AnnotatedString(text),
            constraints = Constraints(),
            style = TextStyle(
                color = HeroTextColor,
                fontSize = masterPxToSp(fontSizeMasterPx),
                fontFamily = KalamRegular,
                letterSpacing = 0.sp,
                textAlign = TextAlign.Start,
                platformStyle = PlatformTextStyle(includeFontPadding = false)
            ),
            softWrap = false,
            maxLines = 1
        )
        val ascentMaster = FontMetrics.ascentMasterPx(fontSizeMasterPx)
        val baselineMasterPx = ascenderAnchorYMasterPx + ascentMaster
        val topLeftYPx = baselineMasterPx * sPx - result.firstBaseline
        return result to topLeftYPx
    }

    val (greetingResult, greetingTopLeftYPx) = remember(greetingText, sPx) {
        measureFixedLine(greetingText, HeroNameSpec.GREETING_ASCENDER_ANCHOR_Y, HeroNameSpec.GREETING_FONT_PX)
    }
    // #22 vertical_reflow.subtitle_shift: ascender anchor moves down by
    // extraNameHeight when line 2 exists; 0 otherwise. Depends on `layout`,
    // so it's remembered against the same keys as `layout` itself.
    val (subtitleResult, subtitleTopLeftYPx) = remember(subtitleText, firstName, secondName, sPx) {
        measureFixedLine(
            subtitleText,
            HeroNameSpec.SUBTITLE_BASE_Y + layout.extraNameHeightMasterPx,
            HeroNameSpec.SUBTITLE_FONT_PX
        )
    }

    Box(
        modifier = modifier
            .size(width = heroWidth, height = heroHeight)
            .clip(RoundedCornerShape(cornerRadius))
    ) {
        // Layer 1: Hero artwork. Source aspect (1.944) == box aspect, so
        // ContentScale.Fit fills the box exactly with zero crop/letterbox.
        Image(
            painter = painterResource(R.drawable.hero_home_final),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(heroWidth, heroHeight)
        )

        // Layer 2: Hero text (name, greeting, subtitle), drawn in one Canvas
        // so all of it uses the
        // exact same measured TextLayoutResults (#22 actual_aligned_bounds_
        // contract "same pipeline" requirement) and the same explicit
        // ascender-anchor/baseline placement technique (#10/#12).
        Canvas(modifier = Modifier.size(heroWidth, heroHeight)) {
            val fillColor = Color(0xFFE91E63)
            val outlineColor = Color(0xFFFFFFFF)
            val outlineStyle = Stroke(width = 1.35f * sPx)

            val nameXPx = HeroNameSpec.NAME_X * sPx
            drawText(
                textLayoutResult = layout.line1,
                color = outlineColor,
                topLeft = Offset(nameXPx, layout.line1DrawTopLeftYPx),
                drawStyle = outlineStyle
            )
            drawText(
                textLayoutResult = layout.line1,
                color = fillColor,
                topLeft = Offset(nameXPx, layout.line1DrawTopLeftYPx),
                drawStyle = Fill
            )
            if (layout.line2 != null && layout.line2DrawTopLeftYPx != null) {
                drawText(
                    textLayoutResult = layout.line2,
                    color = outlineColor,
                    topLeft = Offset(nameXPx, layout.line2DrawTopLeftYPx),
                    drawStyle = outlineStyle
                )
                drawText(
                    textLayoutResult = layout.line2,
                    color = fillColor,
                    topLeft = Offset(nameXPx, layout.line2DrawTopLeftYPx),
                    drawStyle = Fill
                )
            }

            drawText(
                textLayoutResult = greetingResult,
                color = outlineColor,
                topLeft = Offset(HeroNameSpec.GREETING_X * sPx, greetingTopLeftYPx),
                drawStyle = outlineStyle
            )
            drawText(
                textLayoutResult = greetingResult,
                color = fillColor,
                topLeft = Offset(HeroNameSpec.GREETING_X * sPx, greetingTopLeftYPx),
                drawStyle = Fill
            )
            drawText(
                textLayoutResult = subtitleResult,
                color = outlineColor,
                topLeft = Offset(HeroNameSpec.SUBTITLE_X * sPx, subtitleTopLeftYPx),
                drawStyle = outlineStyle
            )
            drawText(
                textLayoutResult = subtitleResult,
                color = fillColor,
                topLeft = Offset(HeroNameSpec.SUBTITLE_X * sPx, subtitleTopLeftYPx),
                drawStyle = Fill
            )
        }
    }
}
