package com.herday.app

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herday.app.ui.HerDayNativeApp
import com.herday.app.ui.theme.HerDayTheme
import com.herday.app.ui.theme.HomeBackground

/**
 * HerDay — Phase 1 (Project Foundation + Home Header + Hero only).
 *
 * Per the approved #07 system-insets contract, the app is edge-to-edge and
 * resolves WindowInsets.safeDrawing itself rather than letting the system
 * reserve fixed status/navigation-bar padding for us.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            navigationBarStyle = SystemBarStyle.light(
                scrim = 0xFFFCE8EF.toInt(),
                darkScrim = 0xFFFCE8EF.toInt()
            )
        )
        setContent {
            HerDayRoot()
        }
    }
}

@Composable
private fun HerDayRoot() {
    HerDayTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = HomeBackground
        ) {
            HerDayNativeApp()
        }
    }
}
