package com.herday.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

/**
 * Phase 1 intentionally uses a minimal Material3 wrapper. The approved Home
 * background/Hero colors are applied directly by HomeScreen/HeroSection from
 * Color.kt rather than through a full app-wide color scheme, since only
 * Header + Hero are in scope for this phase.
 */
private val HerDayLightColors = lightColorScheme(
    background = HomeBackground,
    surface = HomeBackground,
)

@Composable
fun HerDayTheme(content: @Composable () -> Unit) {
    // Phase 1 scope: light scheme only. Dark-theme handling for the rest of
    // the app is out of scope until later phases.
    val colors = HerDayLightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
