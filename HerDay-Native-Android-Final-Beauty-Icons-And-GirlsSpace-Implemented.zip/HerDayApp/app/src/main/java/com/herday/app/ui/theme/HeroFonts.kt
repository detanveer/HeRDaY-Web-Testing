package com.herday.app.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.herday.app.R

/**
 * Exact bundled fonts required by #06 / #23 / #26 for Hero/user names.
 * Hero/user names are now Latin/Roman only (Kalam-Bold) — Noto Nastaliq
 * Urdu is no longer wired into Hero-name rendering (see cleanup report).
 * No system/device font fallback is used anywhere in Hero name rendering
 * or validation.
 */
val KalamRegular = FontFamily(Font(R.font.kalam_regular, FontWeight.Normal))
val KalamBold = FontFamily(Font(R.font.kalam_bold, FontWeight.Bold))
