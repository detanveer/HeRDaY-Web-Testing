package com.herday.app.data

data class Session(val userId: String, val email: String, val accessToken: String, val refreshToken: String)

data class AccountProfile(
    val id: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val cellNumber: String?,
    val avatarPath: String?,
    val role: String,
    val isBlocked: Boolean
) {
    val fullName: String get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
    val isAdmin: Boolean get() = role.equals("admin", true)
}

enum class VerificationStatus(val wire: String) {
    Draft("draft"), Pending("pending"), NeedsCorrection("needs_correction"), Approved("approved");
    companion object { fun from(value: String) = entries.firstOrNull { it.wire == value } }
}

data class BeautyProfile(
    val id: String,
    val ownerId: String,
    val professionalName: String,
    val about: String,
    val professionalPhotoPath: String?,
    val whatsappNumber: String,
    val categories: List<String>,
    val services: List<String>,
    val serviceAreas: List<String>,
    val rawStatus: String,
    val verified: Boolean,
    val isPublic: Boolean,
    val correctionReason: String?,
    val correctionNote: String?
) { val status: VerificationStatus? get() = VerificationStatus.from(rawStatus) }

sealed interface OwnerBeautyState {
    data object Loading : OwnerBeautyState
    data object NoProfile : OwnerBeautyState
    data class Draft(val profile: BeautyProfile) : OwnerBeautyState
    data class NeedsCorrection(val profile: BeautyProfile) : OwnerBeautyState
    data class Pending(val profile: BeautyProfile) : OwnerBeautyState
    data class Approved(val profile: BeautyProfile) : OwnerBeautyState
    data class UnknownExisting(val profile: BeautyProfile) : OwnerBeautyState
    data class Error(val message: String) : OwnerBeautyState
}

fun BeautyProfile.toOwnerState(): OwnerBeautyState = when (status) {
    VerificationStatus.Draft -> OwnerBeautyState.Draft(this)
    VerificationStatus.NeedsCorrection -> OwnerBeautyState.NeedsCorrection(this)
    VerificationStatus.Pending -> OwnerBeautyState.Pending(this)
    VerificationStatus.Approved -> OwnerBeautyState.Approved(this)
    null -> OwnerBeautyState.UnknownExisting(this)
}

data class BeautyDraft(
    val professionalName: String = "",
    val about: String = "",
    val professionalPhotoPath: String? = null,
    val whatsappNumber: String = "",
    val categories: List<String> = emptyList(),
    val services: List<String> = emptyList(),
    val serviceAreas: List<String> = emptyList()
)

val quickBeautyCategories = listOf("Makeup", "Hair", "Mehndi", "Skin & Facial", "Nails", "Waxing")
val allBeautyCategories = listOf(
    "Makeup", "Bridal Services", "Hair", "Mehndi", "Skin & Facial", "Waxing",
    "Threading & Brows", "Nails", "Manicure & Pedicure", "Lashes",
    "Massage & Relaxation", "Other Beauty Services"
)

val correctionReasons = listOf(
    "WhatsApp number does not match",
    "Professional name does not match",
    "Services do not match",
    "Service areas do not match",
    "Voice note not received / cannot be reviewed",
    "Other"
)

class SupabaseException(val code: String?, message: String, val httpStatus: Int) : Exception(message)
