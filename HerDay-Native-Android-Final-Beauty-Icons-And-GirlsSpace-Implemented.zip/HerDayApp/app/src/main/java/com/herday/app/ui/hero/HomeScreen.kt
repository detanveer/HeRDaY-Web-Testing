package com.herday.app.ui.hero

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.herday.app.ui.theme.HomeBackground
import com.herday.app.ui.navigation.FeatureSection

/** Final frozen Home: scrollable body with viewport-fixed navigation. */
@Composable
fun HomeScreen(onFeatureSelected: (FeatureSection) -> Unit) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(HomeBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
    ) {
        val foregroundWidth = maxWidth * 0.92f
        val contentScale = foregroundWidth.value / 882f
        val navHeight = Dp(144 * contentScale)
        val density = LocalDensity.current
        val navigationBarBottom = with(density) {
            WindowInsets.navigationBars.getBottom(this).toDp()
        }

        Column(
            modifier = Modifier
                .fillMaxHeight()
                .width(foregroundWidth)
                .align(Alignment.TopCenter)
                .verticalScroll(rememberScrollState())
        ) {
            HeaderSection(contentScale)
            Spacer(Modifier.height(Dp(20 * contentScale)))
            HeroSection(contentScale, firstName = "Tanveer", secondName = null)
            Spacer(Modifier.height(Dp(20 * contentScale)))
            FinalHomeCards(contentScale, onFeatureSelected)
            Spacer(
                Modifier.height(
                    navHeight +
                        navigationBarBottom +
                        8.dp +
                        Dp(24 * contentScale)
                )
            )
        }

        // Keep the fixed navigation, its clearance, and the system navigation
        // inset on one opaque layer so scrolling content can never show through.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(navHeight + navigationBarBottom + 8.dp)
                .background(HomeBackground)
        )

        BottomNavigation(
            s = contentScale,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Bottom))
                .padding(bottom = 8.dp)
        )
    }
}
