package com.herday.app.ui.hero

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import com.herday.app.R
import com.herday.app.ui.navigation.FeatureSection

private val DmSerif = FontFamily(Font(R.font.dm_serif_display_regular, FontWeight.Normal))
private val Poppins = FontFamily(Font(R.font.poppins_regular, FontWeight.Normal))
private val CardText = Color(0xFF5F344F)
private val SubtitleText = Color(0xFF745B6B)
private val Strip = Color.White
private val Divider = Color(0xFFE8C9DC)

private data class CardSpec(
    val artwork: Int, val icon: Int, val title: String, val subtitle: String,
    val destination: FeatureSection,
    val wide: Boolean = false, val subtitleSize: Float = 21f,
    val iconSize: Float = 90f, val iconX: Float = 25f,
    val showArrow: Boolean = true
)

private val poetry = CardSpec(R.drawable.art_poetry, R.drawable.ic_poetry, "Poetry", "Words from the heart", FeatureSection.Poetry)
private val girls = CardSpec(R.drawable.art_girls_space, R.drawable.ic_girls_space, "Girls' Space", "Conversations. Friendships. You.", FeatureSection.GirlsSpace, subtitleSize = 15.5f, iconX = 27f)
private val explore = CardSpec(R.drawable.art_explore, R.drawable.ic_explore, "Explore", "Discover. Learn. Grow.", FeatureSection.Explore, wide = true, iconX = 27f)
private val dailyTools = CardSpec(R.drawable.art_daily_tools, R.drawable.ic_daily_tools, "Daily Tools", "Plan better. Live brighter.", FeatureSection.DailyTools)
private val beauty = CardSpec(R.drawable.art_beauty_services, R.drawable.ic_beauty_services, "Beauty Services", "Beauty at your doorstep", FeatureSection.BeautyServices, iconX = 27f)
private val horoscope = CardSpec(R.drawable.art_daily_horoscope, R.drawable.ic_daily_horoscope, "Daily Horoscope", "See what the stars say today", FeatureSection.DailyHoroscope, subtitleSize = 17.5f)
private val shop = CardSpec(R.drawable.art_shop, R.drawable.ic_shop, "Shop", "Curated for your everyday.", FeatureSection.Shop, subtitleSize = 20f, iconX = 27f)
private val community = CardSpec(R.drawable.art_community, R.drawable.ic_community, "Community", "Connect, share and grow together.", FeatureSection.Community, wide = true, iconX = 27f)

@Composable
fun FinalHomeCards(s: Float, onFeatureSelected: (FeatureSection) -> Unit) {
    Column {
        PairRow(s, poetry, girls, onFeatureSelected)
        Spacer(Modifier.height(Dp(18 * s)))
        HomeCard(s, explore, onFeatureSelected)
        Spacer(Modifier.height(Dp(17 * s)))
        PairRow(s, dailyTools, beauty, onFeatureSelected)
        Spacer(Modifier.height(Dp(19 * s)))
        PairRow(s, horoscope, shop, onFeatureSelected)
        Spacer(Modifier.height(Dp(21 * s)))
        HomeCard(s, community, onFeatureSelected)
    }
}

@Composable
private fun PairRow(
    s: Float,
    left: CardSpec,
    right: CardSpec,
    onFeatureSelected: (FeatureSection) -> Unit
) {
    Row {
        HomeCard(s, left, onFeatureSelected)
        Spacer(Modifier.width(Dp(20 * s)))
        HomeCard(s, right, onFeatureSelected)
    }
}

@Composable
private fun HomeCard(
    s: Float,
    spec: CardSpec,
    onFeatureSelected: (FeatureSection) -> Unit
) {
    val width = if (spec.wide) 882f else 431f
    val artHeight = if (spec.wide) 346f else 344f
    val stripHeight = if (spec.wide) 116f else 134f
    val cardHeight = artHeight + stripHeight
    Column(
        Modifier
            .size(Dp(width * s), Dp(cardHeight * s))
            .clip(RoundedCornerShape(Dp(28 * s)))
            .clickable { onFeatureSelected(spec.destination) }
    ) {
        Image(
            painterResource(spec.artwork), null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(Dp(width * s), Dp(artHeight * s))
        )
        Box(
            Modifier
                .size(Dp(width * s), Dp(stripHeight * s))
                .background(Strip)
        ) {
            Image(
                painter = painterResource(spec.icon),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .offset(Dp(spec.iconX * s), Dp(((stripHeight - spec.iconSize) / 2f) * s))
                    .size(Dp(spec.iconSize * s))
            )
            Box(
                Modifier
                    .offset(Dp(100 * s), Dp(((stripHeight - 82f) / 2f) * s))
                    .size(Dp(1 * s), Dp(82 * s))
                    .background(Divider)
            )
            Column(
                Modifier
                    .offset(
                        Dp(115 * s),
                        Dp(((stripHeight - 68f) / 2f) * s)
                    )
                    .width(Dp((width - 159f) * s))
            ) {
                Text(
                    spec.title, color = CardText, fontFamily = DmSerif,
                    fontSize = masterSp(35f, s), lineHeight = masterSp(40f, s),
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                )
                Text(
                    spec.subtitle, color = SubtitleText, fontFamily = Poppins,
                    fontSize = masterSp(spec.subtitleSize, s), lineHeight = masterSp(28f, s),
                    maxLines = if (spec.destination == FeatureSection.GirlsSpace) 2 else 1,
                    softWrap = true,
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                )
            }
            if (spec.showArrow) {
                Text(
                    "›", color = Color(0xFFD69AB9), fontFamily = Poppins,
                    fontSize = masterSp(48f, s), textAlign = TextAlign.Center,
                    modifier = Modifier
                        .offset(
                            Dp((width - 34f) * s),
                            Dp(((stripHeight - 48f) / 2f) * s)
                        )
                        .width(Dp(20 * s))
                )
            }
        }
    }
}

private data class NavSpec(val icon: Int, val label: String)
private val navItems = listOf(
    NavSpec(R.drawable.nav_home, "Home"), NavSpec(R.drawable.nav_explore, "Explore"),
    NavSpec(R.drawable.nav_buy_sell, "Buy & Sell"), NavSpec(R.drawable.nav_shop, "Shop"),
    NavSpec(R.drawable.nav_profile, "Profile")
)

@Composable
fun BottomNavigation(
    s: Float,
    modifier: Modifier = Modifier,
    activeIndex: Int = 0,
    onSelected: (Int) -> Unit = {}
) {
    Row(
        modifier
            .size(Dp(882 * s), Dp(144 * s))
            .clip(RoundedCornerShape(Dp(32 * s)))
            .background(Color(0xFFF9EDF6)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        navItems.forEachIndexed { index, item ->
            Column(
                Modifier.width(Dp(176.4f * s)).clickable { onSelected(index) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(item.icon),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(Dp(72 * s))
                )
                Text(
                    item.label,
                    color = if (index == activeIndex) Color(0xFFC42767) else Color(0xFF76586D),
                    fontFamily = DmSerif, fontSize = masterSp(20f, s),
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                )
            }
        }
    }
}

@Composable
private fun masterSp(masterPx: Float, s: Float): TextUnit {
    val density = LocalDensity.current
    return with(density) { (masterPx * s * density.density).toSp() }
}
