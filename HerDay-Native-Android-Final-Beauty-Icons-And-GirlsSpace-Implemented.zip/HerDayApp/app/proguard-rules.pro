# Phase 1 uses no reflection-sensitive libraries beyond standard
# Compose/ICU4J, which ship their own consumer rules. Nothing
# project-specific is required yet.
