// Top-level build file
plugins {
    id("com.android.application") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    // Required starting with Kotlin 2.0: the Compose Compiler now ships as
    // its own Gradle plugin, versioned in lockstep with the Kotlin plugin
    // above (2.0.20), rather than via composeOptions.kotlinCompilerExtensionVersion.
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
