# HerDay — Phase 1 (Project Foundation + Home Header + Hero)

Native Android, Kotlin + Jetpack Compose. This phase implements ONLY the
approved Home background/foundation, Header (logo + notification bell) and
Hero (artwork + dynamic readability mask + typography), per the approved
`#00`–`#26` specification package. No other Home section, bottom
navigation, authentication, or backend is implemented.

## Opening the project

1. Open this folder in Android Studio (Ladybug/2024.2 or newer recommended).
2. Android Studio will offer to generate the Gradle wrapper JAR if it is
   missing — accept that prompt, or run `gradle wrapper` once yourself if
   you have a local Gradle install. **This container has no internet
   access and no Android SDK/Gradle install**, so `gradlew` and
   `gradlew.bat` (plain text scripts) are included and correct, but
   `gradle/wrapper/gradle-wrapper.jar` — a binary — could not be
   downloaded or safely hand-reconstructed here. `gradle-wrapper.properties`
   pins the intended version (Gradle 8.9); nothing about the intended
   Gradle/AGP/Kotlin version was changed to work around this.
3. **For CI (e.g. Codemagic):** `codemagic.yaml` is included with a
   pre-build step that runs `gradle wrapper --gradle-version 8.9
   --distribution-type bin` using the CI image's own Gradle install before
   building — this produces the authentic jar `gradle wrapper` would
   generate locally, rather than a hand-written substitute. If your CI
   config is managed elsewhere, add that one line as the first build step.
   **For a local machine or Android Studio:** open the project; Android
   Studio's bundled Gradle will offer to generate the wrapper jar for you,
   or run `gradle wrapper --gradle-version 8.9 --distribution-type bin`
   yourself once (any local Gradle install works) and commit the result.
4. Let Gradle sync. `minSdk 26`, `targetSdk`/`compileSdk 35`.
5. Run on a device/emulator running Android 8.0 (API 26) or newer.

## What you'll see

The Home background, Header (HerDay logo + notification bell), and Hero
(artwork, readability mask, "Good morning, Tanveer" / subtitle) exactly as
approved. Below the Hero, a **debug-only** name harness (two text fields)
lets you type different First/Second names and watch the approved dynamic
mask, line-assignment, and fitting rules react live — it also lets you
confirm that unsupported scripts (Urdu, Hindi/Devanagari, Bengali, Arabic,
etc.) are correctly rejected, per the current user-name policy below. This
harness is explicitly not production UI (see `DebugNameHarness.kt`) and
should be removed once a real name-entry flow exists in a later phase.

## User/display name policy

**User and Hero display names are English/Roman (Latin-script) only.**
First Name and Second/Last Name are each validated against the Latin
repertoire and rendered with the single bundled **Kalam-Bold** font — no
other script is accepted for a name, and no system/device font fallback
is used. Name rules currently in force:

- First Name maximum = 12 Unicode extended grapheme clusters
- Second/Last Name maximum = 12 Unicode extended grapheme clusters (independent of First Name's limit)
- the generated U+0020 display space exists only when Second/Last is present, and is not itself counted against either field's own 12-cluster limit
- combined display count (First + space + Second/Last) ≤ 12 → both render on Line 1
- combined display count > 12 → First stays on Line 1, Second/Last moves to Line 2
- shared fitting range: 58 → 38 master px, directional End ellipsis if a name still doesn't fit at 38
- dynamic readability-mask extension and two-line mask/subtitle reflow are unchanged by any of the above

**This Latin-only restriction applies to user/display names only — it is
not a statement that HerDay itself is Latin-only.** HerDay's content
(Community posts, questions, poetry, articles, Explore content, and other
app content) is intended to support multiple languages/scripts, including
Urdu, Hindi, Bengali, and Arabic. Those content systems — with their own
fonts, shaping, and RTL/LTR handling — are separate, not-yet-built
features; nothing in this project's architecture prevents adding them
later.

## Structure

```
app/src/main/java/com/herday/app/
  MainActivity.kt                  entry point, edge-to-edge
  ui/theme/                        colors, bundled font families, Theme
  ui/hero/
    HomeScreen.kt                  safe-area + uniform scale + scroll (#07/#18/#19/#20)
    HeaderSection.kt                logo + bell (#08)
    HeroSection.kt                  artwork + mask + text composition (#05/#08/#22), including greeting/subtitle
    HeroNameLayout.kt               line assignment, fitting, mask math (#14/#15/#22/#26)
    HeroMask.kt                     exact edge-feathered mask draw (#05/#16)
    DebugNameHarness.kt             Phase-1-only manual test harness
  util/
    NameValidator.kt                ICU4J-only Latin-script/grapheme/glyph validation (#23/#26)
    TtfCmap.kt                      bundled-font cmap glyph-gate parser
    IcuVersionGuard.kt              ICU4J/Unicode version guard
app/src/main/res/
  font/                            bundled Kalam Regular + Bold (the only Hero/user-name fonts currently wired in)
  drawable/                        background/logo/bell/hero, optimized to lossless WebP
```

## Known limitations of this container build

This container cannot run Android Studio, the Android SDK, or Gradle
(no network access to fetch the SDK/Gradle distribution), so **the project
has not been compiled or run** here. Every formula in `HeroNameLayout.kt`
and `HeroMask.kt` was written directly against the approved JSON specs and
cross-checked by hand, but it has not been visually verified against a real
device render. Please build and run it in Android Studio as the first
verification step, and treat the "Phase 1 verification results" in the
implementation report as spec-traceability checks, not as confirmation of
pixel-perfect on-device output.
